# Rd
# description >> Function to compare ChIP-seq peak sets between one or more test groups and one or more reference groups
# argument
# item >> mat >> reads matrix
# item >> annot >> selected annotation of interest
# item >> ref >> List containing one or more vectors of reference samples. Name of the vectors will be used in the results table. The length of this list should be 1 or the same length as the groups list
# item >> groups >> List containing the IDs of groups to be compared with the reference samples. Names of the vectors will be used in the results table
# item >> featureTab >> Feature annotations to be added to the results table
# value >> Results table
# author >> Celine Vallot 
# keyword >> methods
# details >> ...
# seealso >> ...
# references >> ...
# examples >> ...
# end
geco.CompareedgeRGLM <- function(dataMat=NULL,
								annot=NULL,
					           ref=NULL,
					           groups=NULL,
					           featureTab=NULL,
								    norm_method="RLE"
					           )
{
	res <- featureTab
	for(k in 1:length(groups))
	{
		print(paste("Comparing",names(ref)[min(c(k,length(ref)))],"versus",names(groups)[k]))
		if(length(ref)==1){refsamp <- ref[[1]]}else{refsamp <- ref[[k]]}
		gpsamp <- groups[[k]]
		annot. <- annot[c(refsamp,gpsamp),1:2];annot.$Condition <- c(rep("ref",length(refsamp)),rep("gpsamp",length(gpsamp)))
		mat.<-dataMat [,c(as.character(refsamp),as.character(gpsamp))]
		edgeRgroup <- c(rep(1,length(refsamp)),rep(2,length(gpsamp)))	
		y <- DGEList(counts=mat.,group=edgeRgroup)
		y <- calcNormFactors(y,method=norm_method)
		design <- model.matrix(~edgeRgroup)
		y <- estimateDisp(y, design)		
		fit <- glmFit(y, design)
		comp <- glmLRT(fit, coef=2)
    pvals <- comp$table
		colnames(pvals) <- c("log2FC.gpsamp","logCPM.gpsamp","LR.gpsamp","pval.gpsamp")
    pvals$qval.gpsamp <- p.adjust(pvals$pval.gpsamp, method = "BH")
		res <- data.frame(res,pvals[,c("log2FC.gpsamp","logCPM.gpsamp","pval.gpsamp","qval.gpsamp")])
		colnames(res) <- sub("ref",names(ref)[min(c(k,length(ref)))],sub("gpsamp",names(groups)[k],colnames(res)))		
		
	}
	
	res
}				           

# Rd
# description >> Function to compare ChIP-seq peak sets between one or more test groups and one or more reference groups
# argument
# item >> mat >> reads matrix
# item >> annot >> selected annotation of interest
# item >> ref >> List containing one or more vectors of reference samples. Name of the vectors will be used in the results table. The length of this list should be 1 or the same length as the groups list
# item >> groups >> List containing the IDs of groups to be compared with the reference samples. Names of the vectors will be used in the results table
# item >> featureTab >> Feature annotations to be added to the results table
# value >> Results table
# author >> Celine Vallot 
# keyword >> methods
# details >> ...
# seealso >> ...
# references >> ...
# examples >> ...
# end
geco.CompareWilcox <- function(dataMat=NULL,
                                 annot=NULL,
                                 ref=NULL,
                                 groups=NULL,
                                 featureTab=NULL,
                               logvalues=FALSE
)
{
  res <- featureTab
  for(k in 1:length(groups))
  {
    print(paste("Comparing",names(ref)[min(c(k,length(ref)))],"versus",names(groups)[k]))
    if(length(ref)==1){refsamp <- ref[[1]]}else{refsamp <- ref[[k]]}
    gpsamp <- groups[[k]]
    annot. <- annot[c(refsamp,gpsamp),1:2];annot.$Condition <- c(rep("ref",length(refsamp)),rep("gpsamp",length(gpsamp)))
    mat.<-dataMat [,c(as.character(refsamp),as.character(gpsamp))]
    function(x) wilcox.test(as.numeric(x[as.character(refsamp)]),as.numeric(x[as.character(gpsamp)]))
    
    testWilc <- apply(dataMat,1,function(x) wilcox.test(as.numeric(x[as.character(refsamp)]),as.numeric(x[as.character(gpsamp)])))
    pval.gpsamp <- unlist(lapply(testWilc, function(x) x$p.value))
    qval.gpsamp <- p.adjust(pval.gpsamp, method = "BH")
    Count.gpsamp <- apply(dataMat,1,function(x) mean(x[as.character(gpsamp)]))
    if(logvalues){
    log2FC.gpsamp <- apply(dataMat,1,function(x) (mean(x[as.character(gpsamp)]) - mean(x[as.character(refsamp)])))
    }
    else{
      log2FC.gpsamp <- apply(dataMat,1,function(x) log(mean(x[as.character(gpsamp)])/mean(x[as.character(refsamp)]),2))
      
    }
    res <- data.frame(res,Count.gpsamp,log2FC.gpsamp,pval.gpsamp,qval.gpsamp)
    colnames(res) <- sub("ref",names(ref)[min(c(k,length(ref)))],sub("gpsamp",names(groups)[k],colnames(res)))		
    
  }
  
  res
}				           



# Rd
# description >> Creates a summary table with the number of genes under- or overexpressed in each group and outputs several graphical representations
# argument
# item >> restab >> Results table from geco.ChIPseqCompare
# item >> ref >> List containing one or more vectors of reference samples. Name of the vectors will be used in the results table. The length of this list should be 1 or the same length as the groups list
# item >> groups >> List containing the IDs of groups to be compared with the reference samples. Names of the vectors will be used in the results table
# item >> qval.th >> Q-value threshold to consider a gene as differentially expressed
# item >> plotdir >> Directory to which graphical representations should be plotted
# value >> Summary table
# author >> Eric Letouze & Celine Vallot
# keyword >> methods
# details >> ...
# seealso >> ...
# references >> ...
# examples >> ...
# end
geco.summaryCompareedgeR <- function(restab=NULL,
									  ref=NULL,
							 		  groups=NULL,
  							 		  qval.th=NULL,
                    fc.th=NULL,
							 		  plotdir=NULL
							          )
{
	summary <- matrix(nrow=3,ncol=length(groups),dimnames=list(c("diff","over","under"),names(groups)))
	
	for(k in 1:length(groups))
	{
		gpsamp <- names(groups)[k]
		if(length(ref)==1){refsamp <- names(ref)}else{refsamp <- names(ref)[k]}

		# Fill summary table
		summary["diff",gpsamp] <- sum(restab[,paste("qval",gpsamp,sep=".")] <= qval.th & abs(restab[,paste("log2FC",gpsamp,sep=".")]) > fc.th,na.rm=T)
		summary["over",gpsamp] <- sum(restab[,paste("qval",gpsamp,sep=".")] <= qval.th & restab[,paste("log2FC",gpsamp,sep=".")] > fc.th,na.rm=T)
		summary["under",gpsamp] <- sum(restab[,paste("qval",gpsamp,sep=".")] <= qval.th & restab[,paste("log2FC",gpsamp,sep=".")] < -fc.th,na.rm=T)
		
		pdf(file.path(plotdir,paste("edgeRSupervised_analysis_",gpsamp,".pdf",sep="")))
		# Histogram H1 proportion
		tmp <- geco.H1proportion(restab[,paste("pval",gpsamp,sep=".")])
		hist(restab[,paste("pval",gpsamp,sep=".")],breaks=seq(0,1,by=0.05),xlab="P-value",ylab="Frequency",main=paste(gpsamp," vs ",refsamp,"\n","H1 proportion: ",round(tmp,3),sep=""))
		# Volcano plot
		mycol <- rep("black",nrow(restab))
		mycol[which(restab[,paste("qval",gpsamp,sep=".")] <= qval.th & restab[,paste("log2FC",gpsamp,sep=".")] > fc.th)] <- "red"
		mycol[which(restab[,paste("qval",gpsamp,sep=".")] <= qval.th & restab[,paste("log2FC",gpsamp,sep=".")] < -fc.th)] <- "forestgreen"
		plot(restab[,paste("log2FC",gpsamp,sep=".")],-log10(restab[,paste("qval",gpsamp,sep=".")]),col=mycol,pch=19,cex=0.2,xlab="log2(fold-change)",ylab="-log10(q-value)",las=1,main=paste(gpsamp,"vs",refsamp,"\n",summary["over",gpsamp],"enriched,",summary["under",gpsamp],"depleted"))
		abline(v=0,lty=2);abline(h=-log10(qval.th),lty=2)
		dev.off()
    
		png(file.path(plotdir,paste("edgeR_Volcano_Supervised_analysis_",gpsamp,".png",sep="")),width=1200,height=1200,res=200)
		# Volcano plot
		mycol <- rep("black",nrow(restab))
		mycol[which(restab[,paste("qval",gpsamp,sep=".")] <= qval.th & restab[,paste("log2FC",gpsamp,sep=".")] > fc.th)] <- "red"
		mycol[which(restab[,paste("qval",gpsamp,sep=".")] <= qval.th & restab[,paste("log2FC",gpsamp,sep=".")] < -fc.th)] <- "forestgreen"
		plot(restab[,paste("log2FC",gpsamp,sep=".")],-log10(restab[,paste("qval",gpsamp,sep=".")]),col=mycol,cex=0.7,pch=16,xlab="log2(fold-change)",ylab="-log10(q-value)",las=1,main=paste(gpsamp,"vs",refsamp,"\n",summary["over",gpsamp],"enriched,",summary["under",gpsamp],"depleted"))
		abline(v=fc.th,lty=2);abline(h=-log10(qval.th),lty=2)
		abline(v=-fc.th,lty=2);abline(h=-log10(qval.th),lty=2)
		
		dev.off()
		
		
	}
	
	pdf(file.path(plotdir,"edgeRNumber_differentially_expressed_genes_per_group.pdf"))
	myylim <- range(c(summary["over",],-summary["under",]))
	barplot(summary["over",],col="red",las=1,ylim=myylim,main="Differentially expressed genes",ylab="Nb of genes",axes=F)
	barplot(-summary["under",],col="forestgreen",ylim=myylim,add=T,axes=F,names.arg="")
	z <- axis(2,pos=-10)
	axis(2,at=z,labels=abs(z),las=1)
	dev.off()			
	
	summary
}


# Rd
# description >> Creates a summary table with the number of genes under- or overexpressed in each group and outputs several graphical representations
# argument
# item >> restab >> Results table from geco.ChIPseqCompare
# item >> ref >> List containing one or more vectors of reference samples. Name of the vectors will be used in the results table. The length of this list should be 1 or the same length as the groups list
# item >> groups >> List containing the IDs of groups to be compared with the reference samples. Names of the vectors will be used in the results table
# item >> qval.th >> Q-value threshold to consider a gene as differentially expressed
# item >> plotdir >> Directory to which graphical representations should be plotted
# value >> Summary table
# author >> Eric Letouze & Celine Vallot
# keyword >> methods
# details >> ...
# seealso >> ...
# references >> ...
# examples >> ...
# end
geco.summaryCompareWilcox <- function(restab=NULL,
                                     ref=NULL,
                                     groups=NULL,
                                     qval.th=NULL,
                                     fc.th=NULL,
                                     plotdir=NULL
)
{
  summary <- matrix(nrow=3,ncol=length(groups),dimnames=list(c("diff","over","under"),names(groups)))
  
  for(k in 1:length(groups))
  {
    gpsamp <- names(groups)[k]
    if(length(ref)==1){refsamp <- names(ref)}else{refsamp <- names(ref)[k]}
    
    # Fill summary table
    summary["diff",gpsamp] <- sum(restab[,paste("qval",gpsamp,sep=".")] <= qval.th & abs(restab[,paste("log2FC",gpsamp,sep=".")]) > fc.th,na.rm=T)
    summary["over",gpsamp] <- sum(restab[,paste("qval",gpsamp,sep=".")] <= qval.th & restab[,paste("log2FC",gpsamp,sep=".")] > fc.th,na.rm=T)
    summary["under",gpsamp] <- sum(restab[,paste("qval",gpsamp,sep=".")] <= qval.th & restab[,paste("log2FC",gpsamp,sep=".")] < -fc.th,na.rm=T)
    
    pdf(file.path(plotdir,paste("wilcoxSupervised_analysis_",gpsamp,".pdf",sep="")))
    # Histogram H1 proportion
    tmp <- geco.H1proportion(restab[,paste("pval",gpsamp,sep=".")])
    hist(restab[,paste("pval",gpsamp,sep=".")],breaks=seq(0,1,by=0.05),xlab="P-value",ylab="Frequency",main=paste(gpsamp," vs ",refsamp,"\n","H1 proportion: ",round(tmp,3),sep=""))
    # Volcano plot
    mycol <- rep("black",nrow(restab))
    mycol[which(restab[,paste("qval",gpsamp,sep=".")] <= qval.th & restab[,paste("log2FC",gpsamp,sep=".")] > fc.th)] <- "red"
    mycol[which(restab[,paste("qval",gpsamp,sep=".")] <= qval.th & restab[,paste("log2FC",gpsamp,sep=".")] < -fc.th)] <- "forestgreen"
    plot(restab[,paste("log2FC",gpsamp,sep=".")],-log10(restab[,paste("qval",gpsamp,sep=".")]),col=mycol,pch=19,cex=0.2,xlab="log2(fold-change)",ylab="-log10(q-value)",las=1,main=paste(gpsamp,"vs",refsamp,"\n",summary["over",gpsamp],"enriched,",summary["under",gpsamp],"depleted"))
    abline(v=fc.th,lty=2);abline(h=-log10(qval.th),lty=2); abline(v=-fc.th,lty=2)
    dev.off()
    
    png(file.path(plotdir,paste("wilcox_Volcano_Supervised_analysis_",gpsamp,".png",sep="")),width=1200,height=1200,res=200)
    # Volcano plot
    mycol <- rep("black",nrow(restab))
    mycol[which(restab[,paste("qval",gpsamp,sep=".")] <= qval.th & restab[,paste("log2FC",gpsamp,sep=".")] > fc.th)] <- "red"
    mycol[which(restab[,paste("qval",gpsamp,sep=".")] <= qval.th & restab[,paste("log2FC",gpsamp,sep=".")] < -fc.th)] <- "forestgreen"
    plot(restab[,paste("log2FC",gpsamp,sep=".")],-log10(restab[,paste("qval",gpsamp,sep=".")]),col=mycol,cex=0.7,pch=16,xlab="log2(fold-change)",ylab="-log10(q-value)",las=1,main=paste(gpsamp,"vs",refsamp,"\n",summary["over",gpsamp],"enriched,",summary["under",gpsamp],"depleted"))
    abline(v=fc.th,lty=2);abline(h=-log10(qval.th),lty=2); abline(v=-fc.th,lty=2)
    dev.off()
    
    
  }
  
  pdf(file.path(plotdir,"WilcoxNumber_differentially_bound_genes_per_group.pdf"))
  myylim <- range(c(summary["over",],-summary["under",]))
  barplot(summary["over",],col="red",las=1,ylim=myylim,main="Differentially bound regions",ylab="Nb of regions",axes=F)
  barplot(-summary["under",],col="forestgreen",ylim=myylim,add=T,axes=F,names.arg="")
  z <- axis(2,pos=-10)
  axis(2,at=z,labels=abs(z),las=1)
  dev.off()			
  
  summary
}












