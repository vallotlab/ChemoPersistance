require(geco.utils)

# Rd
# description >> Function to select only one line per variant in an Integragen SNP table
# argument
# item >> snp >> SNP table (Integragen format)
# item >> colUniqueID >> Name of the column containing unique IDs
# item >> colsToUnique >> Columns to which the "unique" function should be applied when concatenating
# item >> colsToPaste >> Columns to which the "paste" function should be applied when concatenating
# value >> SNP table with only one line per variant
# author >> Eric Letouze
# keyword >> methods
# details >> ...
# seealso >> ...
# references >> ...
# examples >> ...
# end
geco.OneLinePerVariant <- function(snp,
								# colUniqueID="uniqueID",
								# colsToPaste=c("refseq","type.pos","index.cdna","index.prot","Taille.cdna","Start","End","codon.wild","aa.wild","codon.mut","aa.mut")
								colUniqueID="varID",
								colsToUnique=c("Gene.name","all.consequences"),
								colsToPaste=c("refseq_prot","type_position") )
{
	tmp <- snp[match(unique(snp[,colUniqueID]),snp[,colUniqueID]),]
	L <- split(snp,snp[,colUniqueID])
	L <- L[tmp[,colUniqueID]]

	for(i in 1:length(colsToUnique))
	{
		tmp[,colsToUnique[i]] <- sapply(L,function(z) paste(unique(z[,colsToUnique[i]]),collapse=","))
	}
	
	for(i in 1:length(colsToPaste))
	{
		tmp[,colsToPaste[i]] <- sapply(L,function(z) paste(z[,colsToPaste[i]],collapse=","))
	}
	
	return(tmp)
}



# Rd
# description >> Function to add useful columns to Integragen SNP table
# argument
# item >> snp >> SNP table (Integragen format)
# value >> SNP table with additional columns
# author >> Eric Letouze
# keyword >> methods
# details >> ...
# seealso >> ...
# references >> ...
# examples >> ...
# end
geco.processIgSnpAnnotationFile <- function(snp=NULL,
											geno.col="genotype", # "genotype""max_gt"
											ref.col="base_ref", # "base_ref" "ref"
											depth.col="depth_used", # "depth_used""used"
											chrom.col="chrom",
											pos.col="position",
											sample.col="sample.ID", # "sample.ID""sample"
											A.col="A",C.col="C",G.col="G",T.col="T",
											Qsnp.col="Qvariant", # "Qvariant""Q.snp."
											Qgeno.col="Qgeno_obs", # "Qgeno_obs""Q.max_gt."
											type.col="all.consequences", # "all.consequenses""typeannot"
											var.col.out="var",
											varCount.col.out="varCount",
											varProp.col.out="varProp",
											varID.col.out="varID",
											uniqueID.col.out="uniqueID",
											X1000G.col="X1000G.EUR.AF", # "X1000G.EUR.AF""X1000Genomes.AF"
											EVS.col="EVS.AF",
											ExAC.col="EXaC.AF"
)
{
	snp[,var.col.out] <- sapply(1:nrow(snp),function(i){
		if(snp[i,geno.col]=="NC"){return("NC")}else{
			return(paste(setdiff(unlist(strsplit(snp[i,geno.col],split="")),snp[i,ref.col]),collapse=","))
		}
	})
	snp[,varCount.col.out] <- sapply(1:nrow(snp),function(i){sum(as.numeric(snp[i,setdiff(c("A","C","G","T"),snp[i,ref.col])]))})
	snp[,varProp.col.out] <- round(snp[,varCount.col.out]/as.numeric(snp[,depth.col]),digits=2)
	
	# Add var ID & unique ID
	snp[,varID.col.out] <- paste(snp[,chrom.col],snp[,pos.col],snp[,ref.col],snp[,var.col.out],sep="_")
	snp[,uniqueID.col.out] <- paste(snp[,sample.col],snp[,varID.col.out],sep="_")
	
	# Simplify count column names and convert to numeric
	for(col in c(A.col,C.col,G.col,T.col,depth.col,Qsnp.col,Qgeno.col,X1000G.col,EVS.col,ExAC.col)){snp[,col] <- as.numeric(snp[,col])}

	# Add "coding" column
	if(type.col %in% c("all.consequences","all.consequenses")){
		snp$coding <- as.logical(geco.simplifyTypeannot_vep(snp[,type.col]) %in% c("nonsense","splice","frameshift","inframe_indel","missense","synonymous","coding_sequence_variant"))
	}
	if(type.col=="typeannot"){
		snp$coding <- as.logical(geco.simplifyTypeannot(snp[,type.col]) %in% c("nonsense","missense","splice","synonymous"))
	}
	
	return(snp)
}




# Rd
# description >> Function to add useful columns to Integragen indel table
# argument
# item >> indel >> Indel table (Integragen format)
# value >> Indel table with additional columns
# author >> Eric Letouze
# keyword >> methods
# details >> ...
# seealso >> ...
# references >> ...
# examples >> ...
# end
geco.processIgIndelAnnotationFile <- function(indel=NULL,
											ref.indel.col="ref.indel", #
											indel.reads.col="indel_reads", #
											depth.col="depth", #
											chrom.col="chrom", #
											pos.col="position", # "position""Position"
											sample.col="sample.ID", #
											Qindel.col="Q.indel", # "Q.indel""Q.indel."
											Qgeno.col="Qgeno_obs", # "Qgeno_obs""Q.max_gtype."
											ref.col.out="ref",
											var.col.out="var",
											varCount.col.out="varCount",
											varProp.col.out="varProp",
											length.col.out="length",
											varID.col.out="varID",
											uniqueID.col.out="uniqueID",
											type.col="all.consequences", # "all.consequences""type"											
											X1000G.col="X1000G.EUR.AF", # "X1000G.EUR.AF""X1000Genomes.AF"
											EVS.col="EVS.AF",
											ExAC.col="EXaC.AF"
)
{
	indel[,ref.col.out] <- sapply(1:nrow(indel),function(i){unlist(strsplit(indel[i,ref.indel.col],split="/"))[1]})
	indel[,var.col.out] <- sapply(1:nrow(indel),function(i){unlist(strsplit(indel[i,ref.indel.col],split="/"))[2]})
	indel[,varCount.col.out] <- indel[,indel.reads.col]
	indel[,varProp.col.out] <- indel[,varCount.col.out]/indel[,depth.col]
	indel[,length.col.out] <- nchar(indel[,ref.col.out])
	
	# Add var ID & unique ID
	indel[,varID.col.out] <- paste(indel[,chrom.col],indel[,pos.col],indel[,ref.col.out],indel[,var.col.out],sep="_")
	indel[,uniqueID.col.out] <- paste(indel[,sample.col],indel[,varID.col.out],sep="_")
		
	# Convert numeric columns to numeric
	for(col in c(depth.col,Qindel.col,Qgeno.col,X1000G.col,EVS.col,ExAC.col)){indel[,col] <- as.numeric(indel[,col])}
		
	# Add "coding" column
	if(type.col %in% c("all.consequences","all.consequenses")){
		indel$coding <- as.logical(geco.simplifyTypeannot_vep(indel[,type.col]) %in% c("nonsense","splice","frameshift","inframe_indel","missense","synonymous","coding_sequence_variant"))
	}
	if(type.col=="typeannot"){
		snp$coding <- FALSE
		snp[grep("exon|splice",indel[,type.col]),"coding"] <- TRUE
	}

	return(indel)
}


# Rd
# description >> required
# argument
# item >> snp >> SNP table (integragen family format)
# item >> samp >> Sample IDs (must correspond to suffixes in column names)
# value >> SNP table with additional columns
# author >> Eric Letouze
# keyword >> methods
# details >> ...
# seealso >> ...
# references >> ...
# examples >> ...
# end
geco.processIgSnpFamilyFile <- function(snp=NULL,samp=NULL,
											geno.col="genotype", # "genotype""max_gt"
											ref.col="ref",
											depth.col="depth_used", # "depth_used""used"
											chrom.col="chrom",
											pos.col="position", # "position""Position"
											filt.col="base_filtered", # "base_filtered""filt"
											Qsnp.col="Qvariant", # "Qvariant""Q.snp."
											Qgeno.col="Qgeno_obs", # "Qgeno_obs""Q.max_gt."
											type.col="all.consequences", # "all.consequences""typeannot"
											X1000G.col="X1000G.EUR.AF", # "X1000G.EUR.AF""X1000Genomes.AF"
											EVS.col="EVS.AF",
											ExAC.col="EXaC.AF"
)
{
	print("Adding var, varCount & varProp columns")
	for(s in samp)
	{
		print(s)
		snp[,paste("var",s,sep=".")] <- sapply(1:nrow(snp),function(i){
			if(snp[i,paste(geno.col,s,sep=".")]=="NC"){return("NC")}else{
				return(paste(setdiff(unlist(strsplit(snp[i,paste(geno.col,s,sep=".")],split="")),snp[i,ref.col]),collapse=","))
			}
		})
		snp[,paste("varCount",s,sep=".")] <- sapply(1:nrow(snp),function(i){sum(as.numeric(snp[i,paste(setdiff(c("A","C","G","T"),snp[i,ref.col]),s,sep=".")]))})
		snp[,paste("varProp",s,sep=".")] <- round(snp[,paste("varCount",s,sep=".")]/as.numeric(snp[,paste(depth.col,s,sep=".")]),digits=2)	
	}
	snp$varAll <- sapply(1:nrow(snp),function(i){paste(unique(setdiff(as.character(snp[i,grep("^var\\.",colnames(snp))]),c("","NC"))),collapse=",")})
	snp$varID <- paste(snp[,chrom.col],snp[,pos.col],snp[,ref.col],snp$varAll,sep="_")

	# Simplify count column names and convert to numeric
	print("Converting numeric columns to numeric format")
	for(s in samp){
		for(colName in c("A","C","G","T",depth.col,filt.col,Qsnp.col,Qgeno.col)){
			snp[,paste(colName,s,sep=".")] <- as.numeric(snp[,paste(colName,s,sep=".")])
		}
	}
		for(col in c(X1000G.col,EVS.col,ExAC.col)){snp[,col] <- as.numeric(snp[,col])}

	# Remove potential duplicate columns
	rmcol <- c("var","freq.var.norm","freq.var.tum","count.all.var.norm","count.all.var.tum")
	rmcol <- intersect(rmcol,colnames(snp))
	if(length(rmcol))	snp <- snp[,-which(colnames(snp) %in% rmcol)]
	
	# Add "coding" column
	if(type.col %in% c("all.consequences","all.consequenses")){
		snp$coding <- as.logical(geco.simplifyTypeannot_vep(snp[,type.col]) %in% c("nonsense","splice","frameshift","inframe_indel","missense","synonymous","coding_sequence_variant"))
	}
	if(type.col=="typeannot"){
		snp$coding <- as.logical(geco.simplifyTypeannot(snp[,type.col]) %in% c("nonsense","missense","splice","synonymous"))
	}
	
	return(snp)
}



# Rd
# description >> required
# argument
# item >> indel >> Indel table (integragen family format)
# item >> samp >> Sample IDs (must correspond to suffixes in column names)
# value >> Indel table with additional columns
# author >> Eric Letouze
# keyword >> methods
# details >> ...
# seealso >> ...
# references >> ...
# examples >> ...
# end
geco.processIgIndelFamilyFile <- function(indel=NULL,samp=NULL,
											ref.indel.col="ref.indel", #
											indel.reads.col="indel_reads", #
											depth.col="depth", #
											chrom.col="chrom", #
											pos.col="position", # "position""Position"
											Qindel.col="Q.indel", # "Q.indel""Q.indel."
											Qgeno.col="Qgeno_obs", # "Qgeno_obs""Q.max_gtype."
											type.col="all.consequences", # "all.consequences""type"
											X1000G.col="X1000G.EUR.AF", # "X1000G.EUR.AF""X1000Genomes.AF"
											EVS.col="EVS.AF",
											ExAC.col="EXaC.AF"
)
{
		# Simplify count column names and convert to numeric
	print("Converting numeric columns to numeric format")
	for(s in samp){
		for(colName in c(Qindel.col,Qgeno.col,indel.reads.col,depth.col)){
			indel[,paste(colName,s,sep=".")] <- as.numeric(indel[,paste(colName,s,sep=".")])
		}
		}
		for(col in c(X1000G.col,EVS.col,ExAC.col)){indel[,col] <- as.numeric(indel[,col])}

	print("Adding var, varCount & varProp columns")
	indel[,ref.indel.col] <- as.character(sapply(1:nrow(indel),function(i){paste(setdiff(unique(sapply(indel[i,paste(ref.indel.col,samp,sep=".")],function(z) unlist(strsplit(z,"/"))[1])),NA),collapse=",")}))
	for(s in samp)
	{
		print(s)
		indel[,paste("var",s,sep=".")] <- sapply(indel[,paste(ref.indel.col,s,sep=".")],function(z) unlist(strsplit(z,"/"))[2])
		indel[which(is.na(indel[,paste("var",s,sep=".")])),paste("var",s,sep=".")] <- ""
		indel[,paste("varCount",s,sep=".")] <- indel[,paste(indel.reads.col,s,sep=".")]
		indel[,paste("varProp",s,sep=".")] <- round(indel[,paste("varCount",s,sep=".")]/indel[,paste(depth.col,s,sep=".")],digits=2)
		indel[,paste("length",s,sep=".")] <- nchar(indel[,paste("var",s,sep=".")])
	}
	indel$varAll <- sapply(1:nrow(indel),function(i){paste(unique(setdiff(as.character(indel[i,grep("^var\\.",colnames(indel))]),c("","NC"))),collapse=",")})
	indel$varID <- paste(indel[,chrom.col],indel[,pos.col],indel[,ref.indel.col],indel$varAll,sep="_")
	
	# Remove potential duplicate columns
	rmcol <- c("var","freq.var.norm","freq.var.tum","count.all.var.norm","count.all.var.tum")
	rmcol <- intersect(rmcol,colnames(indel))
	if(length(rmcol))	indel <- indel[,-which(colnames(indel) %in% rmcol)]
	
	# Add "coding" column
	if(type.col %in% c("all.consequences","all.consequenses")){
		indel$coding <- as.logical(geco.simplifyTypeannot_vep(indel[,type.col]) %in% c("nonsense","splice","frameshift","inframe_indel","missense","synonymous","coding_sequence_variant"))
	}
	if(type.col=="typeannot"){
		indel$coding <- FALSE
		indel[grep("exon|splice",indel[,type.col]),"coding"] <- TRUE
	}

	return(indel)
}



# Rd
# description >> This function takes as input a SNP table as generated by geco.processIgSnpAnnotationFile and selects relevant SNPs using a set of filters
# argument
# item >> snp >> SNP table annotated with geco.processIgSnpAnnotationFile
# item >> mincov >> Minimum coverage
# item >> minvarcount >> Minimum number of reads containing the SNP
# item >> minvarprop >> Minimum proportion of reads containing the SNP
# item >> minQsnp >> Minimum Qphred for the presence of a SNP
# item >> minQmaxgt >> Minimum Qphred for the genotype of the SNP
# item >> filtrs >> Logical indicating wether SNPs with an rs ID should be filtered?
# item >> max1000G >> Maximum frequency of a SNP at this position in 1000G data
# item >> maxEVS >> Maximum frequency of a SNP at this position in EVS data
# item >> maxIG.HTZ.th >> Maximum frequency of heterozygous SNP in Integragen controls
# item >> maxIG.HOM.th >> Maximum frequency of homozygous SNP in Integragen controls
# item >> OneLinePerVariant >> Logical indicating wether the results table should be summarized with a single line per variant
# item >> rmcdsprot >> Logical indicating wether cds & prot columns should be filtered
# value >> SNP table restricted to reliable coding SNPs
# author >> Eric Letouzé
# keyword >> methods
# details >> September 23, 2013
# seealso >> ...
# references >> ...
# examples >> ...
# end
geco.getReliableSNPs <- function(snp,
							mincov=10,
							minvarcount=5,
							minvarprop=0.3,
							minQsnp=20,
							minQmaxgt=20,
							maxIG.HTZ.th=1,
							maxIG.HOM.th=1,
							OneLinePerVariant=TRUE,
							colsToPaste=c("IMPACT", "transcript", "type_position", "refseq_prot", "protein_variation", "codon.wild.mut", "HGVSc", "HGVSp"),
							colsToUnique=c("Gene.name","all.consequences", "strand"),
							maxExAC=1,
							max1000G=1,
							maxEVS=1,
							depth.col="depth_used", # "depth_used""used"
							Qsnp.col="Qvariant", # "Qvariant""Q.snp."
							Qgeno.col="Qgeno_obs", # "Qgeno_obs""Q.max_gt."
							IG.HTZ.col="IG.HTZ.AF", # "IG.HTZ.AF""IG.HTZ.Percent"
							IG.Hom.col="IG.Hom.AF", # "IG.Hom.AF""IG.Hom.Percent"
							X1000G.col="X1000G.EUR.AF", # "X1000G.EUR.AF""X1000Genomes.AF"
							EVS.col="EVS.AF",
							ExAC.col="EXaC.AF",
							varCount.col="varCount",
							varProp.col="varProp"
							)
{
	sel <- which(
	snp[,depth.col] >= mincov & 
	snp[,varCount.col] >= minvarcount & 
	snp[,varProp.col] >= minvarprop & 
	snp[,Qsnp.col] >= minQsnp & 
	snp[,Qgeno.col] >= minQmaxgt & 
	(snp[,ExAC.col] <= maxExAC | is.na(snp[,ExAC.col])) & 
	(snp[,X1000G.col] <= max1000G | is.na(snp[,X1000G.col])) & 
	(snp[,EVS.col] <= maxEVS | is.na(snp[,EVS.col])) & 
	snp[,IG.HTZ.col] <= maxIG.HTZ.th & 
	snp[,IG.Hom.col] <= maxIG.HOM.th)
	
	res <- snp[sel,]
	if(OneLinePerVariant){res <- geco.OneLinePerVariant(res,colUniqueID="varID",colsToPaste=colsToPaste)}
	return(res)
}


# Rd
# description >> This function takes as input a SNP table as generated by geco.processIgSnpFamilyFile and selects reliable SNPs using a set of filters
# argument
# item >> snp >> SNP table annotated with geco.processIgSnpFamilyFile
# item >> mincov >> Minimum coverage
# item >> minvarcount >> Minimum number of reads containing the SNP
# item >> minvarprop >> Minimum proportion of reads containing the SNP
# item >> minQsnp >> Minimum Qphred for the presence of a SNP
# item >> minQmaxgt >> Minimum Qphred for the genotype of the SNP
# item >> filtrs >> Logical indicating wether SNPs with an rs ID should be filtered?
# item >> max1000G >> Maximum frequency of a SNP at this position in 1000G data
# item >> maxEVS >> Maximum frequency of a SNP at this position in EVS data
# item >> maxIG.HTZ.th >> Maximum frequency of heterozygous SNP in Integragen controls
# item >> maxIG.HOM.th >> Maximum frequency of homozygous SNP in Integragen controls
# item >> OneLinePerVariant >> Logical indicating wether the results table should be summarized with a single line per variant
# item >> rmcdsprot >> Logical indicating wether cds & prot columns should be filtered
# value >> SNP table restricted to reliable coding SNPs
# author >> Sylvain Guibert
# keyword >> methods
# details >> Aout 08, 2016
# seealso >> ...
# references >> ...
# examples >> ...
# end
geco.getReliableSNPsFamily <- function(snp,
							samp=NULL,
							mincov=10,
							minvarcount=5,
							minvarprop=0.3,
							minQsnp=20,
							minQmaxgt=20,
							filtrs=FALSE,
							maxIG.HTZ.th=1,
							maxIG.HOM.th=1,
							OneLinePerVariant=TRUE,
							colsToPaste=c("IMPACT", "transcript", "type_position", "refseq_prot", "protein_variation", "codon.wild.mut", "HGVSc", "HGVSp"),
							colsToUnique=c("Gene.name","all.consequences", "strand"),
							maxExAC=1,
							max1000G=1,
							maxEVS=1,
							depth.col="depth_used", # "used""depth_used"
							Qsnp.col="Qvariant", # "Q.snp.""Qvariant"
							Qgeno.col="Qgeno_obs", # "Q.max_gt.""Qgeno_obs"
							IG.HTZ.col="IG.HTZ.AF", # "IG.HTZ.Percent""IG.HTZ.AF"
							IG.Hom.col="IG.Hom.AF", # "IG.Hom.Percent""IG.Hom.AF"
							X1000G.col="X1000G.EUR.AF", # "X1000Genomes.AF""X1000G.EUR.AF"
							EVS.col="EVS.AF",
							ExAC.col="EXaC.AF",
							varCount.col="varCount",
							varProp.col="varProp"
							)
{
for(s in samp){
	print(s)
	sel <- which(
	snp[,paste(depth.col,s,sep=".")] >= mincov & 
	snp[,paste(varCount.col,s,sep=".")] >= minvarcount & 
	snp[,paste(varProp.col,s,sep=".")] >= minvarprop & 
	snp[,paste(Qsnp.col,s,sep=".")] >= minQsnp & 
	snp[,paste(Qgeno.col,s,sep=".")] >= minQmaxgt & 
	(snp[,ExAC.col] <= maxExAC | is.na(snp[,ExAC.col])) & 
	(snp[,X1000G.col] <= max1000G | is.na(snp[,X1000G.col])) & 
	(snp[,EVS.col] <= maxEVS | is.na(snp[,EVS.col])) & 
	snp[,IG.HTZ.col] <= maxIG.HTZ.th & 
	snp[,IG.Hom.col] <= maxIG.HOM.th)
	
	snp[,paste("sel",s,sep=".")] <- FALSE
	snp[sel,paste("sel",s,sep=".")] <- TRUE
	if(OneLinePerVariant){snp <- geco.OneLinePerVariant(snp,colUniqueID="varID",colsToPaste=colsToPaste)}
}	
return(snp)
}


# Rd
# description >> This function takes as input an Indel table as generated by geco.processIgIndelAnnotationFile and selects reliable indels using a set of filters
# argument
# item >> indel >> Indel table annotated with geco.processIgIndelAnnotationFile
# item >> mincov >> Minimum coverage
# item >> minvarcount >> Minimum number of reads containing the SNP
# item >> minvarprop >> Minimum proportion of reads containing the SNP
# item >> maxLength >> Maximum length of the indel
# item >> minQindel >> Minimum Qphred for the presence of an indel
# item >> minQmaxgt >> Minimum Qphred for the genotype of the indel
# item >> filtrs >> Logical indicating wether SNPs with an rs ID should be filtered?
# item >> max1000G >> Maximum frequency of a SNP at this position in 1000G data
# item >> maxEVS >> Maximum frequency of a SNP at this position in EVS data
# item >> maxIG.HTZ.th >> Maximum frequency of heterozygous SNP in Integragen controls
# item >> maxIG.HOM.th >> Maximum frequency of homozygous SNP in Integragen controls
# item >> OneLinePerVariant >> Logical indicating wether the results table should be summarized with a single line per variant
# value >> Indel table restricted to reliable coding indels
# author >> fisrtName1 lastName1
# keyword >> methods
# details >> ...
# seealso >> ...
# references >> ...
# examples >> ...
# end
geco.getReliableIndels <- function(indel,
								mincov=10,
								minvarcount=5,
								minvarprop=0.3,
								maxLength=1000,
								minQindel=30,
								minQmaxgt=20,
								maxIG.HTZ.th=1,
								maxIG.HOM.th=1,
								OneLinePerVariant=TRUE,
								colsToPaste=c("IMPACT", "transcript", "type_position", "refseq_prot", "protein_variation", "codon.wild.mut", "HGVSc", "HGVSp"),
								colsToUnique=c("Gene.name","all.consequences", "strand"),
								maxExAC=1,
								max1000G=1,
								maxEVS=1,
								Qindel.col="Q.indel", # "Q.indel""Q.indel."
								Qgeno.col="Qgeno_obs", # "Qgeno_obs""Q.max_gtype."
								depth.col="depth",
								length.col="length",
								IG.HTZ.col="IG.HTZ.AF", # "IG.HTZ.AF""IG.HTZ.Percent"
								IG.Hom.col="IG.Hom.AF", # "IG.Hom.AF""IG.Hom.Percent"
								X1000G.col="X1000G.EUR.AF", # "X1000G.EUR.AF""X1000Genomes.AF"
								EVS.col="EVS.AF",
								ExAC.col="EXaC.AF",
								varCount.col="varCount",
								varProp.col="varProp"
								)
{
	sel <- which(
	indel[,depth.col] >= mincov & 
	indel[,varCount.col] >= minvarcount & 
	indel[,varProp.col] >= minvarprop & 
	indel[,length.col] <= maxLength & 
	indel[,Qindel.col] >= minQindel & 
	indel[,Qgeno.col] >= minQmaxgt & 
	(indel[,ExAC.col] <= maxExAC | is.na(indel[,ExAC.col])) & 
	(indel[,X1000G.col] <= max1000G | is.na(indel[,X1000G.col])) & 
	(indel[,EVS.col] <= maxEVS | is.na(indel[,EVS.col])) & 
	indel[,IG.HTZ.col] <= maxIG.HTZ.th & 
	indel[,IG.Hom.col] <= maxIG.HOM.th)
	
	res <- indel[sel,]
	if(OneLinePerVariant){res <- geco.OneLinePerVariant(res,colUniqueID="varID",colsToPaste=colsToPaste)}
	return(res)
}



# Rd
# description >> This function takes as input an Indel table as generated by geco.processIgIndelFamilyFile and selects reliable indels using a set of filters
# argument
# item >> indel >> Indel table annotated with geco.processIgIndelFamilyFile
# item >> mincov >> Minimum coverage
# item >> minvarcount >> Minimum number of reads containing the SNP
# item >> minvarprop >> Minimum proportion of reads containing the SNP
# item >> maxLength >> Maximum length of the indel
# item >> minQindel >> Minimum Qphred for the presence of an indel
# item >> minQmaxgt >> Minimum Qphred for the genotype of the indel
# item >> filtrs >> Logical indicating wether SNPs with an rs ID should be filtered?
# item >> max1000G >> Maximum frequency of a SNP at this position in 1000G data
# item >> maxEVS >> Maximum frequency of a SNP at this position in EVS data
# item >> maxIG.HTZ.th >> Maximum frequency of heterozygous SNP in Integragen controls
# item >> maxIG.HOM.th >> Maximum frequency of homozygous SNP in Integragen controls
# item >> OneLinePerVariant >> Logical indicating wether the results table should be summarized with a single line per variant
# value >> Indel table restricted to reliable coding indels
# author >> Sylvain Guibert
# keyword >> methods
# details >> Aout 08, 2016
# seealso >> ...
# references >> ...
# examples >> ...
# end
geco.getReliableIndelsFamily <- function(indel,
								samp=NULL,
								mincov=10,
								minvarcount=5,
								minvarprop=0.3,
								maxLength=1000,
								minQindel=30,
								minQmaxgt=20,
								maxIG.HTZ.th=1,
								maxIG.HOM.th=1,
								OneLinePerVariant=TRUE,
								colsToPaste=c("IMPACT", "transcript", "type_position", "refseq_prot", "protein_variation", "codon.wild.mut", "HGVSc", "HGVSp"),
								colsToUnique=c("Gene.name","all.consequences", "strand"),
								maxExAC=1,
								max1000G=1,
								maxEVS=1,
								Qindel.col="Q.indel", # "Q.indel""Q.indel."
								Qgeno.col="Qgeno_obs", # "Q.max_gtype.""Qgeno_obs"
								depth.col="depth",
								length.col="length",
								IG.HTZ.col="IG.HTZ.AF", # "IG.HTZ.Percent""IG.HTZ.AF"
								IG.Hom.col="IG.Hom.AF", # "IG.Hom.Percent""IG.Hom.AF"
								X1000G.col="X1000G.EUR.AF", # "X1000Genomes.AF""X1000G.EUR.AF"
								EVS.col="EVS.AF",
								ExAC.col="EXaC.AF",
								varCount.col="varCount",
								varProp.col="varProp"
								)
{
for(s in samp){
	print(s)
	sel <- which(
	indel[,paste(depth.col,s,sep=".")] >= mincov & 
	indel[,paste(varCount.col,s,sep=".")] >= minvarcount & 
	indel[,paste(varProp.col,s,sep=".")] >= minvarprop & 
	indel[,paste(length.col,s,sep=".")] <= maxLength & 
	indel[,paste(Qindel.col,s,sep=".")] >= minQindel & 
	indel[,paste(Qgeno.col,s,sep=".")] >= minQmaxgt & 
	(indel[,ExAC.col] <= maxExAC | is.na(indel[,ExAC.col])) & 
	(indel[,X1000G.col] <= max1000G | is.na(indel[,X1000G.col])) & 
	(indel[,EVS.col] <= maxEVS | is.na(indel[,EVS.col])) & 
	indel[,IG.HTZ.col] <= maxIG.HTZ.th & 
	indel[,IG.Hom.col] <= maxIG.HOM.th)
	
	indel[,paste("sel",s,sep=".")] <- FALSE
	indel[sel,paste("sel",s,sep=".")] <- TRUE	
	if(OneLinePerVariant){indel <- geco.OneLinePerVariant(indel,colUniqueID="varID",colsToPaste=colsToPaste)}
}	
return(indel)
}



# Rd
# description >> This function takes as input a SNP table as generated by geco.processIgSnpFamilyFile and selects reliable somatic SNPs using a set of filters
# argument
# item >> snp >> SNP table annotated with geco.processIgSnpFamilyFile
# item >> normsamp >> name of normal sample
# item >> tumsamp >> name of tumor sample
# item >> mincov.N >> Minimum coverage in normal sample
# item >> mincov.T >> Minimum coverage in normal sample
# item >> minvarcount.T >> Minimum number of variant reads in the tumor
# item >> minvarprop.T >> Minimum proportion of variant reads in the tumor
# item >> maxvarcount.N >> Maximum number of variant reads in the normal
# item >> maxvarprop.N >> Maximum proportion of variant reads in the normal
# item >> minQsnp >> Minimum Qphred for the presence of a SNP in the tumor
# item >> minQmaxgt >> Minimum Qphred for the genotype of the SNP
# item >> maxIG.HTZ.th >> Maximum frequency of heterozygous SNP in Integragen controls
# item >> maxIG.HOM.th >> Maximum frequency of homozygous SNP in Integragen controls
# item >> OneLinePerVariant >> Logical indicating wether the results table should be summarized with a single line per variant
# item >> maxExAC >> Maximum frequency of a SNP at this position in ExAC data
# item >> max1000G >> Maximum frequency of a SNP at this position in 1000G data
# item >> maxEVS >> Maximum frequency of a SNP at this position in EVS data
# item >> depth.col >> required
# item >> Qsnp.col >> required
# item >> Qgeno.col >> required
# item >> IG.HTZ.col >> required
# item >> IG.Hom.col >> required
# item >> X1000G.col >> required
# item >> EVS.col >> required
# item >> ExAC.col >> required
# item >> varCount.col >> required
# item >> varProp.col >> required
# item >> doplot >> Should a plot of VAF in N vs T by drawn
# item >> plot.file >> Name of file to export the plot
# value >> SNP table restricted to reliable somatic SNPs
# author >> Eric Letouze
# keyword >> methods
# details >> August 23, 2016
# seealso >> ...
# references >> ...
# examples >> ...
# end
geco.getSomaticSNPs <- function(snp,
						    normsamp=NULL,
						    tumsamp=NULL,
							mincov.N=10,
							mincov.T=10,
							minvarcount.T=3,
							minvarprop.T=0.15,
							maxvarcount.N=1,
							maxvarprop.N=0.05,
							minQsnp=20,
							minQmaxgt=20,
							maxIG.HTZ.th=1,
							maxIG.HOM.th=1,
							OneLinePerVariant=TRUE,
							colsToPaste=c("IMPACT", "transcript", "type_position", "refseq_prot", "protein_variation", "codon.wild.mut", "HGVSc", "HGVSp"),
							colsToUnique=c("Gene.name","all.consequences", "strand"),
							maxExAC=1,
							max1000G=1,
							maxEVS=1,
							depth.col="depth_used", # "used""depth_used"
							Qsnp.col="Qvariant", # "Q.snp.""Qvariant"
							Qgeno.col="Qgeno_obs", # "Q.max_gt.""Qgeno_obs"
							IG.HTZ.col="IG.HTZ.AF", # "IG.HTZ.Percent""IG.HTZ.AF"
							IG.Hom.col="IG.Hom.AF", # "IG.Hom.Percent""IG.Hom.AF"
							X1000G.col="X1000G.EUR.AF", # "X1000Genomes.AF""X1000G.EUR.AF"
							EVS.col="EVS.AF",
							ExAC.col="EXaC.AF",
							varCount.col="varCount",
							varProp.col="varProp",
							doplot=FALSE,
							plot.file=NULL
							)
{
	# Select reliable variants
	sel <- which(
	snp[,paste(depth.col,normsamp,sep=".")] >= mincov.N & 
	snp[,paste(depth.col,tumsamp,sep=".")] >= mincov.T & 
	(snp[,X1000G.col] <= max1000G | is.na(snp[,X1000G.col])) & 
	(snp[,EVS.col] <= maxEVS | is.na(snp[,EVS.col])) & 
	(snp[,ExAC.col] <= maxExAC | is.na(snp[,ExAC.col])) & 
	snp[,IG.HTZ.col] <= maxIG.HTZ.th & 
	snp[,IG.Hom.col] <= maxIG.HOM.th)
	snp <- snp[sel,]
	
    # Select somatic variants
	sel <- which(
	snp[,paste(Qsnp.col,tumsamp,sep=".")] >= minQsnp & 
	snp[,paste(Qgeno.col,tumsamp,sep=".")] >= minQmaxgt & 
    snp[,paste(varCount.col,normsamp,sep=".")] <= maxvarcount.N & 
	snp[,paste(varCount.col,tumsamp,sep=".")] >= minvarcount.T & 
	snp[,paste(varProp.col,normsamp,sep=".")] <= maxvarprop.N & 
	snp[,paste(varProp.col,tumsamp,sep=".")] >= minvarprop.T)

	# Plot N/T variant proportions
	if(doplot){
		mycol <- rep("black",nrow(snp));mycol[sel] <- "red"
		png(plot.file,res=100)
		plot(snp[,paste(varProp.col,normsamp,sep=".")],snp[,paste(varProp.col,tumsamp,sep=".")],col=mycol,cex=0.5,xlab="Matched non-tumor sample",ylab="Tumor sample",main="Variant Allele Fraction",las=1,xlim=c(0,1),ylim=c(0,1))
		abline(h=minvarprop.T,lty=2,col="red")
		abline(v=maxvarprop.N,lty=2,col="red")
		dev.off()
	}
	snp <- snp[sel,]
	
	# Keep one line per variant and return somatic SNVs
	if(OneLinePerVariant){snp <- geco.OneLinePerVariant(snp,colUniqueID="varID",colsToPaste=colsToPaste)}
	return(snp)
}


# Rd
# description >> This function takes as input a Indel table as generated by geco.processIgIndelFamilyFile and selects reliable somatic SNPs using a set of filters
# argument
# item >> snp >> SNP table annotated with geco.processIgSnpFamilyFile
# item >> normsamp >> name of normal sample
# item >> tumsamp >> name of tumor sample
# item >> mincov.N >> Minimum coverage in normal sample
# item >> mincov.T >> Minimum coverage in normal sample
# item >> minvarcount.T >> Minimum number of variant reads in the tumor
# item >> minvarprop.T >> Minimum proportion of variant reads in the tumor
# item >> maxvarcount.N >> Maximum number of variant reads in the normal
# item >> maxvarprop.N >> Maximum proportion of variant reads in the normal
# item >> maxLength >> Maximum length for the indel (long indels are often less reliable than short ones)
# item >> minQindel >> Minimum Qphred for the presence of an indel in the tumor
# item >> minQmaxgt >> Minimum Qphred for the genotype of the SNP
# item >> maxIG.HTZ.th >> Maximum frequency of heterozygous SNP in Integragen controls
# item >> maxIG.HOM.th >> Maximum frequency of homozygous SNP in Integragen controls
# item >> OneLinePerVariant >> Logical indicating wether the results table should be summarized with a single line per variant
# item >> maxExAC >> Maximum frequency of a SNP at this position in ExAC data
# item >> max1000G >> Maximum frequency of a SNP at this position in 1000G data
# item >> maxEVS >> Maximum frequency of a SNP at this position in EVS data
# item >> Qindel.col >> required
# item >> Qgeno.col >> required
# item >> depth.col >> required
# item >> length.col >> required
# item >> IG.HTZ.col >> required
# item >> IG.Hom.col >> required
# item >> X1000G.col >> required
# item >> EVS.col >> required
# item >> ExAC.col >> required
# item >> varCount.col >> required
# item >> varProp.col >> required
# item >> doplot >> Should a plot of VAF in N vs T by drawn
# item >> plot.file >> Name of file to export the plot
# value >> SNP table restricted to reliable somatic SNPs
# author >> Eric Letouze
# keyword >> methods
# details >> August 23, 2016
# seealso >> ...
# references >> ...
# examples >> ...
# end
geco.getSomaticIndels <- function(snp,
						    normsamp=NULL,
						    tumsamp=NULL,
							mincov.N=10,
							mincov.T=10,
							minvarcount.T=3,
							minvarprop.T=0.15,
							maxvarcount.N=1,
							maxvarprop.N=0.05,
							maxLength=1000,
							minQindel=30,
							minQmaxgt=20,
							maxIG.HTZ.th=1,
							maxIG.HOM.th=1,
							OneLinePerVariant=TRUE,
							colsToPaste=c("IMPACT", "transcript", "type_position", "refseq_prot", "protein_variation", "codon.wild.mut", "HGVSc", "HGVSp"),
							colsToUnique=c("Gene.name","all.consequences", "strand"),
							maxExAC=1,
							max1000G=1,
							maxEVS=1,
							Qindel.col="Q.indel", # "Q.indel""Q.indel."
							Qgeno.col="Qgeno_obs", # "Q.max_gt.""Qgeno_obs"
							depth.col="depth",
							length.col="length",
							IG.HTZ.col="IG.HTZ.AF", # "IG.HTZ.Percent""IG.HTZ.AF"
							IG.Hom.col="IG.Hom.AF", # "IG.Hom.Percent""IG.Hom.AF"
							X1000G.col="X1000G.EUR.AF", # "X1000Genomes.AF""X1000G.EUR.AF"
							ExAC.col="EXaC.AF",
							EVS.col="EVS.AF",
							varCount.col="varCount",
							varProp.col="varProp",
							doplot=FALSE,
							plot.file=NULL
							)
{
	# Select reliable variants
	sel <- which(
	indel[,paste(depth.col,normsamp,sep=".")] >= mincov.N & 
	indel[,paste(depth.col,tumsamp,sep=".")] >= mincov.T & 
	indel[,paste(length.col,tumsamp,sep=".")] <= maxLength & 
	(indel[,X1000G.col] <= max1000G | is.na(indel[,X1000G.col])) & 
	(indel[,EVS.col] <= maxEVS | is.na(indel[,EVS.col])) & 
	(indel[,ExAC.col] <= maxExAC | is.na(indel[,ExAC.col])) & 
	indel[,IG.HTZ.col] <= maxIG.HTZ.th & 
	indel[,IG.Hom.col] <= maxIG.HOM.th)
	indel <- indel[sel,]
	
    # Select somatic variants
	sel <- which(
	indel[,paste(Qindel.col,tumsamp,sep=".")] >= minQindel & 
	indel[,paste(Qgeno.col,tumsamp,sep=".")] >= minQmaxgt & 
    indel[,paste(varCount.col,normsamp,sep=".")] <= maxvarcount.N & 
	indel[,paste(varCount.col,tumsamp,sep=".")] >= minvarcount.T & 
	indel[,paste(varProp.col,normsamp,sep=".")] <= maxvarprop.N & 
	indel[,paste(varProp.col,tumsamp,sep=".")] >= minvarprop.T)

	# Plot N/T variant proportions
	if(doplot){
		mycol <- rep("black",nrow(indel));mycol[sel] <- "royalblue"
		png(plot.file,res=100)
		plot(indel[,paste(varProp.col,normsamp,sep=".")],indel[,paste(varProp.col,tumsamp,sep=".")],col=mycol,cex=0.5,xlab="Matched non-tumor sample",ylab="Tumor sample",main="Variant Allele Fraction",las=1,xlim=c(0,1),ylim=c(0,1))
		abline(h=minvarprop.T,lty=2,col="royalblue")
		abline(v=maxvarprop.N,lty=2,col="royalblue")
		dev.off()
	}
	indel <- indel[sel,]
	
	# Keep one line per variant and return somatic SNVs
	if(OneLinePerVariant){indel <- geco.OneLinePerVariant(indel,colUniqueID="varID",colsToPaste=colsToPaste)}
	return(indel)
}


# Rd
# description >> Function to extract data from the INFO and FORMAT columns in a vcf
# argument
# item >> vcf >> Vcf table in which data should be extracted
# item >> INFO.fields >> Name of fields to extract in the INFO column
# item >> INFO.colnames >> Name of columns to give to fields extracted in INFO
# item >> FORMAT.fields >> Name of fields to extract in the FORMAT column
# item >> FORMAT.colnames >> Name of columns to give to fields extracted in FORMAT
# item >> sampcol >> Name of variant columns to be included
# value >> Annotated vcf
# author >> Eric Letouze
# keyword >> methods
# details >> ...
# seealso >> ...
# references >> ...
# examples >> ...
# end
extractFieldsFromVCF <- function(vcf=NULL,
							INFO.fields=NULL,
							INFO.colnames=NULL,
							FORMAT.fields=NULL,
							FORMAT.colnames=NULL,
							sampcol=NULL
							)
{
	nvar <- nrow(vcf)
	
	# Extract fields from INFO column
	if(!is.null(INFO.fields)){
		print("Extracting selected fields from INFO columns")
		info <- lapply(vcf$INFO,function(z){unlist(strsplit(z,";"))})
		info <- unlist(lapply(info,function(z){
			ind <- match(INFO.fields,sapply(z,function(z){head(unlist(strsplit(z,"=")),1)}))
			sapply(z,function(z){tail(unlist(strsplit(z,"=")),1)})[ind]
		}))
		info <- data.frame(matrix(info,nrow=nvar,byrow=T))
		colnames(info) <- INFO.colnames
		vcf <- data.frame(vcf,info)	
	}
	
	# Extract fields from sample columns
	if(!is.null(FORMAT.fields) & !is.null(sampcol))
	{
		ind <- lapply(vcf$FORMAT,function(z){match(FORMAT.fields,unlist(strsplit(z,":")))})
		for(s in sampcol)
		{
			print(paste("Extracting selected FORMAT fields for sample:",s))
			tmp <- lapply(1:nrow(vcf),function(i){
				unlist(strsplit(vcf[i,s],":"))[ind[[i]]]
			})
			tmp <- data.frame(matrix(unlist(tmp),nrow=nvar,byrow=T))
			colnames(tmp) <- paste(s,FORMAT.colnames,sep="_")
			vcf <- data.frame(vcf,tmp)
		}
	}
	return(factoall(vcf))
}								





# Rd
# description >> This function simplifies Integragen typeannot fields by returning the most "damaging" effect.
# argument
# item >> typeannot >> vector typeannot to be simplified
# value >> required
# author >> Eric Letouze
# keyword >> methods
# details >> ...
# seealso >> ...
# references >> ...
# examples >> ...
# end
geco.simplifyTypeannot <- function(typeannot){
	typeannot[grep("nonsense",typeannot)] <- "nonsense"
	typeannot[grep("missense",typeannot)] <- "missense"
	typeannot[grep("splice",typeannot)] <- "splice"
	typeannot[grep("synonymous",typeannot)] <- "synonymous"
	typeannot[grep("intron",typeannot)] <- "intron"
	typeannot[grep("5-UTR",typeannot)] <- "5-UTR"
	typeannot[grep("3-UTR",typeannot)] <- "3-UTR"
	typeannot[which(typeannot=="")] <- "intergenic"
	typeannot
}





# Rd
# description >> This function simplifies VEP typeannot fields by returning the most "damaging" effect.
# argument
# item >> typeannot >> vector typeannot to be simplified
# value >> required
# author >> Eric Letouze
# keyword >> methods
# details >> ...
# seealso >> ...
# references >> ...
# examples >> ...
# end
geco.simplifyTypeannot_vep <- function(typeannot){
#	typeannot[grep("stop_gained",typeannot)] <- "stop_gained"
#	typeannot[grep("stop_lost",typeannot)] <- "stop_lost"
#	typeannot[grep("start_lost",typeannot)] <- "start_lost"
	typeannot[grep("stop_lost|stop_gained|start_lost",typeannot)] <- "nonsense"
	typeannot[grep("splice_acceptor|splice_donor",typeannot)] <- "splice"
	typeannot[grep("frameshift_variant",typeannot)] <- "frameshift"
	typeannot[grep("inframe",typeannot)] <- "inframe_indel"
	typeannot[grep("missense",typeannot)] <- "missense"
	typeannot[grep("splice_region",typeannot)] <- "splice_region"
	typeannot[grep("stop_retained|synonymous",typeannot)] <- "synonymous"
	typeannot[grep("intron",typeannot)] <- "intron"
	typeannot[grep("5_prime_UTR",typeannot)] <- "5-UTR"
	typeannot[grep("3_prime_UTR",typeannot)] <- "3-UTR"
	typeannot[grep("intergenic|downstream_gene_variant|upstream_gene_variant",typeannot)] <- "intergenic"
	typeannot
}




# Rd
# description >> Function to add CancerGeneCensus informations in an Integragen SNP table
# argument
# item >> snp >> SNP table (Integragen format)
# item >> CGCfile >> Full path to CancerGeneCensus File
# item >> colsToAdd >> Columns from CGC to add to the snp table
# value >> SNP table with CGC annotation
# author >> Eric Letouze
# keyword >> methods
# details >> ...
# seealso >> ...
# references >> ...
# examples >> ...
# end

geco.CancerGeneCensus <- function(snp = snp_som_all,
								CGCfile="/illumina/runs/GeCo/GeCo.Bioinf/GeCo.Annotation/hg19/Census_allThu_Oct_8_16_03_12_2015.txt",
								colsToAdd = c("CGC.Gene.Symbol","CGC.Tumour.Types.Somatic", "CGC.Tumour.Types.Germline", "CGC.Mutation.Types", "CGC.Translocation.Partner") # c("CGC.Tumour.Types.Somatic", "CGC.Tumour.Types.Germline", "CGC.Mutation.Types", "CGC.Translocation.Partner")
){
CGC <- read.delim(paste0(CGCfile), as.is=TRUE)
colnames(CGC) <- paste0("CGC.", colnames(CGC))
# remove CGC IG columns in snp tables
if( sum(grepl("CancerGeneCensus", colnames(snp))) >0 )    snp <- subset(snp, select=-grep("CancerGeneCensus", colnames(snp)) )

# Column with yes if gene exists in CGC
for(col in c("CancerGeneCensus", colsToAdd)){snp[,col] <- ""}
inCGC <- grep(paste(paste(paste("^",CGC$CGC.Gene.Symbol,"$",sep=""),collapse="|"),paste(paste("^",CGC$CGC.Gene.Symbol,",",sep=""),collapse="|"),paste(paste(",",CGC$CGC.Gene.Symbol,",",sep=""),collapse="|"),paste(paste(",",CGC$CGC.Gene.Symbol,"$",sep=""),collapse="|"),sep="|"),snp$Gene.name)
snp[inCGC,"CancerGeneCensus"] <- "yes"
for(i in inCGC){
	ind <- which(CGC$CGC.Gene.Symbol %in% unlist(strsplit(snp$Gene.name[i],",")))
	for(col in colsToAdd){
		snp[i,col] <- paste(CGC[ind,col],collapse=",")
	}
}

return(snp)

}




# Rd
# description >> This function receives a vector so of concatenated SO fields and a vector so.ord of ordered SO fields (e.g. from the most to the least damaging) and returns for each element in so the most damaging of the concatenated fields
# argument
# item >> so >> Concatenated SO fields
# item >> so.ord >> Ordered SO fields (e.g. from the most to the least damaging)
# value >> Simplified so vector with only the most damaging field for each concatenated list
# author >> Eric Letouze
# keyword >> methods
# details >> ...
# seealso >> ...
# references >> ...
# examples >> ...
# end

geco.mostDamagingSO <- function(so=NULL,
							    so.ord=NULL){
	so <- gsub("&",",",so)
	if(length(setdiff(unlist(strsplit(so,",")),so.ord))){print("Warning: so fields not found in so.ord")}
	for(i in 1:length(so.ord)){
		tmp <- paste(paste(paste("^",so.ord[i],"$",sep=""),collapse="|"),paste(paste("^",so.ord[i],",",sep=""),collapse="|"),paste(paste(",",so.ord[i],",",sep=""),collapse="|"),paste(paste(",",so.ord[i],"$",sep=""),collapse="|"),sep="|")
		so[grep(tmp,so)] <- so.ord[i]
	}
	so
}






