# Rd
# description >> Function to compare Methylation Data and RNA-seq data
# argument
# item >> methylTable >> methyl table with rownames being gene_id
# item >> Exptable >> expression table with rownames being gene_id
# item >> ref >> List containing one or more vectors of reference samples. Name of the vectors will be used in the results table. The length of this list should be 1 or the same length as the groups list
# item >> groups >> List containing one or more vectors of samples to compare with reference samples. Name of the vectors will be used in the results table. 
# item >> qval.th >> treshold for qvalue
# item >> deltaM >> treshold for deltaM
# value >> summaryTable >> table with all over-expressed & hypo-methylated genes, and under-expressed and hyper-methylated genes in groups vs reference
# author >> Celine Vallot 
# keyword >> methods
# details >> produces pdf and tables of gene lists
# seealso >> ...
# references >> ...
# examples >> ...
# end
geco.ExpMethylCompare <- function(methylTable=NULL,
					  	  	   ExpTable=NULL,
					  	  		ref=NULL,
					           groups=NULL,
					           qval.th=0.1,
					           deltaM=0.05
					           )					           
{
			summaryTable <- matrix(nrow=4,ncol=length(groups),dimnames=list(c("over-hypo","OH.p.value","under-hyper","UH.p.value"),groups))		
			common<-merge(ExpTable,methylTable,by='row.names')$Row.names
			ExpTable <- ExpTable [common,]
			methylTable <- methylTable [common,]
			
	for(k in 1:length(groups))
	{
		if(length(ref)==1){nomref <- ref[1]}else{nomref  <- ref[k]}
		nomgp<-groups[k]
	
		over <- (ExpTable[,paste("qval",nomgp,sep=".")] <= qval.th & ExpTable[,paste("log2FC",nomgp,sep=".")] > 0)
		hypo <- (methylTable[,paste("qval",nomgp,sep=".")] <= qval.th 	& methylTable[,paste("delta",nomgp,sep=".")] < -deltaM )
		under <- (ExpTable[,paste("qval",nomgp,sep=".")] <= qval.th & ExpTable[,paste("log2FC",nomgp,sep=".")] < 0)
		hyper <- (methylTable[,paste("qval",nomgp,sep=".")] <= qval.th 	& methylTable[,paste("delta",nomgp,sep=".")] > deltaM )
		
		pdf(file.path(plotdir,paste("Comparison Methylation and Expression_",nomgp,"vs",nomref," .pdf",sep="")))
		plot(ExpTable[,paste("log2FC.",nomgp,sep="")] ~ methylTable[,paste("delta.",nomgp,sep="")],main=paste("Comparison Methylation and Expression",nomgp,"vs",nomref,sep=" "),ylab="expression log2FC",xlab="methylation delta",pch=16,col=ifelse(over & hypo, 2 , ifelse(under & hyper,3,1)),cex=0.7)
		dev.off()
		
		summaryTable["over-hypo",nomgp] <- sum(over & hypo,na.rm=T )
		summaryTable["OH.p.value",nomgp] <- sum(dhyper(summaryTable["over-hypo",nomgp]:min(sum(hypo,na.rm=T),sum(over,na.rm=T)),max(sum(hypo,na.rm=T),sum(over,na.rm=T)), length(common)-max(sum(hypo,na.rm=T),sum(over,na.rm=T)) , min(sum(hypo,na.rm=T),sum(over,na.rm=T))))
		summaryTable["under-hyper",nomgp] <- sum(under & hyper,na.rm=T )	
		summaryTable["UH.p.value",nomgp] <- sum(dhyper(summaryTable["under-hyper",nomgp]:min(sum(hyper,na.rm=T),sum(under,na.rm=T)),max(sum(hyper,na.rm=T),sum(under,na.rm=T)), length(common)-max(sum(hyper,na.rm=T),sum(under,na.rm=T)) , min(sum(hyper,na.rm=T),sum(under,na.rm=T))))
		overTable <- cbind ( ExpTable[over & hypo, c("gene_name",paste("log2FC",nomgp,sep=".") , paste("qval",nomgp,sep=".")) ] , 	methylTable[over & hypo, c(paste("delta",nomgp,sep=".") , paste("qval",nomgp,sep=".")) ] )
		colnames(overTable)[5]<-paste("qvalMet",nomgp,sep=".")
		underTable <- cbind ( ExpTable[under & hyper, c("gene_name",paste("log2FC",nomgp,sep=".") , paste("qval",nomgp,sep=".")) ] , 	methylTable[under & hyper, c(paste("delta",nomgp,sep=".") , 				 paste("qval",nomgp,sep=".")) ] )
				colnames(underTable)[5]<-paste("qvalMet",nomgp,sep=".")

		write.table(overTable,file.path(tabdir,paste("OverExpressed_HypoMethylatedGenes_",nomgp,"vs",nomref," .csv",sep="")),quote=F,sep=";",row.names=F)
		write.table(underTable,file.path(tabdir,paste("UnderExpressed_HyperMethylatedGenes_",nomgp,"vs",nomref," .csv",sep="")),quote=F,sep=";",row.names=F)

	
	}
	
	write.table(summaryTable,file.path(tabdir,"ComparisonMethylExpression.csv"),quote=F,sep=";")
	pdf(file.path(plotdir,"Number_differentially_expressed&methylated_genes_per_group.pdf"))
	myylim <- range(c(summaryTable["over-hypo",],-summaryTable["under-hyper",]))
	barplot(summaryTable["over-hypo",],col="red",las=1,ylim=myylim,main="Differentially expressed & methylated genes",ylab="Nb of genes",axes=F)
	barplot(-summaryTable["under-hyper",],col="forestgreen",ylim=myylim,add=T,axes=F,names.arg="")
	z <- axis(2,pos=-10)
	axis(2,at=z,labels=abs(z),las=1)
	dev.off()
	
	return(summaryTable)

}		



