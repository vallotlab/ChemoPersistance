# Rd
# description >> required
# argument
# item >> ChIPTable >> ChIP table with column closest_gene
# item >> ExpTable >> expression table with column Gene
# item >> ref >> List containing one or more vectors of reference samples. Name of the vectors will be used in the results table. The length of this list should be 1 or the same length as the groups list
# item >> groups >> List containing one or more vectors of samples to compare with reference samples. Name of the vectors will be used in the results table. 
# item >> qval.th >> treshold for qvalue
# item >> nbrGenes >> number of annotated genes in Transcriptome Annot
# value >> summaryTable >> table with all intersection and corresponding pvalue of hypergeometric test
# author >> Celine Vallot
# keyword >> methods
# details >> produces pdf and tables of gene lists
# seealso >> ...
# references >> ...
# examples >> ...
# end

geco.ExpChIPseqCompare <- function(ChIPTable=NULL,
					  	  	   ExpTable=NULL,
					  	  		ref=NULL,
					           groups=NULL,
					           qval.th=0.1,
					           nbrGenes=NULL
					           )					           
{
			##creating a summary Table for all conditions
			summaryTable <- as.data.frame(matrix(nrow=8,ncol=length(groups)+1))			
			colnames(summaryTable) <- c("comparison",groups)
			summaryTable$comparison <- c("over-enriched","OEhypergeo.p.value","under-depleted","UDhypergeo.p.value","over-depleted","ODhypergeo.p.value","under-enriched","UEhypergeo.p.value")
			rownames(summaryTable) <- summaryTable$comparison
			
	for(k in 1:length(groups))
	{
		
		if(length(ref)==1){refsamp <- ref[1]}else{refsamp <- ref[k]}
		gpsamp <-groups[k]
print(gpsamp); flush.console()	
		over <- ExpTable$Gene[(ExpTable[,paste("qval",gpsamp,sep=".")] <= qval.th & ExpTable[,paste("log2FC",gpsamp,sep=".")] > 0)]
		depleted <- unique(ChIPTable$closest_gene[(ChIPTable[,paste("qval",gpsamp,sep=".")] <= qval.th 	& ChIPTable[,paste("log2FC",gpsamp,sep=".")] < 0 )])
		under <- ExpTable$Gene[(ExpTable[,paste("qval",gpsamp,sep=".")] <= qval.th & ExpTable[,paste("log2FC",gpsamp,sep=".")] < 0)]
		enriched <- unique(ChIPTable$closest_gene[(ChIPTable[,paste("qval",gpsamp,sep=".")] <= qval.th 	& ChIPTable[,paste("log2FC",gpsamp,sep=".")] > 0 )])
	
		over <- over[!is.na(over)]	
		depleted <- depleted[!is.na(depleted)]
		under <- under[!is.na(under)]	
		enriched <- enriched[!is.na(enriched)]
		
		OE <- intersect(over,enriched)
		UD <- intersect(under,depleted)
		OD <- intersect(over,depleted) #SG
		UE <- intersect(under,enriched) #SG

		summaryTable["over-enriched",gpsamp] <- length(OE)
		summaryTable["OEhypergeo.p.value",gpsamp] <- (1- phyper(length(OE),length(enriched),nbrGenes-length(enriched),length(over)))
		summaryTable["under-depleted",gpsamp] <- length(UD)	
		summaryTable["UDhypergeo.p.value",gpsamp] <- (1- phyper(length(UD),length(depleted),nbrGenes-length(depleted),length(under)))
		summaryTable["over-depleted",gpsamp] <- length(OD) #SG
		summaryTable["ODhypergeo.p.value",gpsamp] <- (1- phyper(length(OD),length(depleted),nbrGenes-length(depleted),length(over))) #SG
		summaryTable["under-enriched",gpsamp] <- length(UE)	 #SG
		summaryTable["UEhypergeo.p.value",gpsamp] <- (1- phyper(length(UE),length(enriched),nbrGenes-length(enriched),length(under))) #SG

		if(length(over)>0 &length(enriched)>0){	
		venn.diagram(list(OverExpressed = over,Enriched = enriched),filename=file.path(plotdir,paste("VennDiagram_OverExpressed-Enriched_",gpsamp,"-vs-",refsamp,".tiff",sep="")),fill = c("red", "yellow"),alpha = c(0.5, 0.5),cex=1.3,main=paste("Comparison ChIPseq and Expression",gpsamp,"vs",refsamp,sep=" "), sub=paste("p-value=",summaryTable["OEhypergeo.p.value",gpsamp],sep=""), margin=0.1,cat.cex=1.3,cat.dist=0.03)
		}
		if(length(under)>0 &length(depleted)>0){	
		venn.diagram(list(UnderExpressed = under,Depleted = depleted),filename=file.path(plotdir,paste("VennDiagram_UnderExpressed-Depleted_",gpsamp,"-vs-",refsamp,".tiff",sep="")),fill = c("green", "blue"),alpha = c(0.5, 0.5),cex=1.3,main=paste("Comparison ChIPseq and Expression",gpsamp,"vs",refsamp,sep=" "), sub=paste("p-value=",summaryTable["UDhypergeo.p.value",gpsamp],sep=""), margin=0.1,cat.cex=1.3,cat.dist=0.03)
		}
		if(length(over)>0 &length(depleted)>0){	
		venn.diagram(list(OverExpressed = over,Depleted = depleted),filename=file.path(plotdir,paste("VennDiagram_OverExpressed-Depleted_",gpsamp,"-vs-",refsamp,".tiff",sep="")),fill = c("red", "blue"),alpha = c(0.5, 0.5),cex=1.3,main=paste("Comparison ChIPseq and Expression",gpsamp,"vs",refsamp,sep=" "), sub=paste("p-value=",summaryTable["ODhypergeo.p.value",gpsamp],sep=""), margin=0.1,cat.cex=1.3,cat.dist=0.03) #SG
		}
		if(length(under)>0 &length(enriched)>0){	
		venn.diagram(list(UnderExpressed = under,Enriched = enriched),filename=file.path(plotdir,paste("VennDiagram_UnderExpressed-Enriched_",gpsamp,"-vs-",refsamp,".tiff",sep="")),fill = c("green", "yellow"),alpha = c(0.5, 0.5),cex=1.3,main=paste("Comparison ChIPseq and Expression",gpsamp,"vs",refsamp,sep=" "), sub=paste("p-value=",summaryTable["UEhypergeo.p.value",gpsamp],sep=""), margin=0.1,cat.cex=1.3,cat.dist=0.03) #SG
		}
		
		##creating a table common for plotting of fold change in chip versus expression, for this you need to have a common set of genes with a unique FC for expression and ChIP 
		a <- paste("qval",gpsamp,sep=".")
		tmp <- split(ChIPTable,ChIPTable$closest_gene)
		tmp <- lapply(tmp,function(x)
		  x[ x[,a] == min( x[,a] ),] )
		ChIPunique <- do.call(rbind,tmp)
		ChIPunique <- ChIPunique[!duplicated(ChIPunique$closest_gene),] ##les doublons restant sont des égalités , meme qvalue
		ChIPunique <- na.omit(ChIPunique)
		row.names(ChIPunique) <- ChIPunique$closest_gene	
		colnames(ChIPunique) <- paste("ChIP",colnames(ChIPunique),sep="_")	
		
		common<-merge(ExpTable,ChIPunique,by='row.names')
		common<- subset(common,select=-c(Row.names))
		
		##creating a table all with all information of expression, and ChIP when available
		all <- merge(ExpTable,ChIPunique,by='row.names',all.x = TRUE)
		all <- subset(all,select=-c(Row.names))
		
		pdf(file.path(plotdir,paste("Comparison_ChIPseq_Expression_",gpsamp,"-vs-",refsamp,".pdf",sep="")))

		common$color <- "black"
		common$color[common$Gene %in% OE] <- "red"
		common$color[common$Gene %in% UD] <- "forestgreen"
		
		common$text <- ""
		common$text[common$Gene %in% OE] <- common$Gene[common$Gene %in% OE]
		common$text[common$Gene %in% UD] <- common$Gene[common$Gene %in% UD]

		plot(common[,paste("log2FC.",gpsamp,sep="")] ~ common[,paste("ChIP_","log2FC.",gpsamp,sep="")],main=paste("Comparison ChIPseq and Expression",gpsamp,"vs",refsamp,sep=" "),ylab="expression log2FC",xlab="binding log2FC",pch=16,cex=0.7,col=common$color)
		abline(h=0,lty=2)
		abline(v=0,lty=2)
		
		plot(common[,paste("log2FC.",gpsamp,sep="")] ~ common[,paste("ChIP_","log2FC.",gpsamp,sep="")],main=paste("Comparison ChIPseq and Expression",gpsamp,"vs",refsamp,sep=" "),ylab="expression log2FC",xlab="binding log2FC",pch=16,cex=0.7,col=common$color)
		text(common[,paste("ChIP_","log2FC.",gpsamp,sep="")],common[,paste("log2FC.",gpsamp,sep="")], labels=common$text,pos=1,cex=0.6)
		abline(h=0,lty=2)
		abline(v=0,lty=2)
		
		dev.off()
		
		common<- subset(common,select=-c(text,color))
		
		if(length(OE)>0){	
		overenrichedTable <- common[common$Gene %in% OE, c("Gene","chr",paste("qval",gpsamp,sep="."),paste("log2FC",gpsamp,sep="."),"ChIP_chr","ChIP_start","ChIP_end","ChIP_closest_gene","ChIP_distance",paste("ChIP_","log2FC.",gpsamp,sep=""),paste("ChIP_","qval.",gpsamp,sep=""))]
		write.table(overenrichedTable,file.path(tabdir,paste("OverExpressed_Enriched_Genes_",gpsamp,"-vs-",refsamp,".csv",sep="")),quote=F,sep=";",row.names=F)
		}
		
		if(length(UD)>0){	
		underdepletedTable <- common[common$Gene %in% UD,c("Gene","chr",paste("qval",gpsamp,sep="."),paste("log2FC",gpsamp,sep="."),"ChIP_chr","ChIP_start","ChIP_end","ChIP_closest_gene","ChIP_distance",paste("ChIP_","log2FC.",gpsamp,sep=""),paste("ChIP_","qval.",gpsamp,sep=""))]
		write.table(underdepletedTable,file.path(tabdir,paste("UnderExpressed_Depleted_Genes_",gpsamp,"-vs-",refsamp,".csv",sep="")),quote=F,sep=";",row.names=F)
		}
	
		if(length(OD)>0){	
		overdepletedTable <- common[common$Gene %in% OD, c("Gene","chr",paste("qval",gpsamp,sep="."),paste("log2FC",gpsamp,sep="."),"ChIP_chr","ChIP_start","ChIP_end","ChIP_closest_gene","ChIP_distance",paste("ChIP_","log2FC.",gpsamp,sep=""),paste("ChIP_","qval.",gpsamp,sep=""))] 
		write.table(overdepletedTable,file.path(tabdir,paste("OverExpressed_Depleted_Genes_",gpsamp,"-vs-",refsamp,".csv",sep="")),quote=F,sep=";",row.names=F) #SG
		}
		
		if(length(UE)>0){	
		underenrichedTable <- common[common$Gene %in% UE, c("Gene","chr",paste("qval",gpsamp,sep="."),paste("log2FC",gpsamp,sep="."),"ChIP_chr","ChIP_start","ChIP_end","ChIP_closest_gene","ChIP_distance",paste("ChIP_","log2FC.",gpsamp,sep=""),paste("ChIP_","qval.",gpsamp,sep=""))] 
		write.table(underenrichedTable,file.path(tabdir,paste("UnderExpressed_Enriched_Genes_",gpsamp,"-vs-",refsamp,".csv",sep="")),quote=F,sep=";",row.names=F) #SG
		}

		write.table(all,file.path(tabdir,paste("Complete_Table_ChIPseq_Expression_",gpsamp,"-vs-",refsamp,".csv",sep="")),quote=F,sep=";",row.names=F)
		
	
	}

	write.table(summaryTable,file.path(tabdir,"Comparison_ChIPseq_Expression.csv"),quote=F,sep=";",row.names=F)

system(sprintf("rm -f %s/*.log",plotdir))
	
	return(summaryTable)
	
}		


