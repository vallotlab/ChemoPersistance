# Rd
# description >> Function to compare ChIP-seq peak sets between one or more test groups and one or more reference groups using DESeq
# argument
# item >> mat >> pseudocount matrix
# item >> annot >> selected annotation of interest
# item >> ref >> List containing one or more vectors of reference samples. Name of the vectors will be used in the results table. The length of this list should be 1 or the same length as the groups list
# item >> groups >> List containing the IDs of groups to be compared with the reference samples. Names of the vectors will be used in the results table
# item >> featureTab >> Feature annotations to be added to the results table
# value >> Results table
# author >> Celine Vallot & Eric Letouze
# keyword >> methods
# details >> ...
# seealso >> ...
# references >> ...
# examples >> ...
# end
geco.ChIPseqCompare <- function(mat=NULL,
								annot=NULL,
					           ref=NULL,
					           groups=NULL,
					           featureTab=NULL
					           )
{
	res <- featureTab
	for(k in 1:length(groups))
	{
		print(paste("Comparing",names(ref)[min(c(k,length(ref)))],"versus",names(groups)[k]))
		if(length(ref)==1){refsamp <- ref[[1]]}else{refsamp <- ref[[k]]}
		gpsamp <- groups[[k]]
		annot. <- annot[c(refsamp,gpsamp),1:2];annot.$Condition <- c(rep("ref",length(refsamp)),rep("gpsamp",length(gpsamp)))
		mat.<-mat [,c(refsamp,gpsamp)]
		cds. <- newCountDataSet(mat.,annot.$Condition)
		pData(cds.)$sizeFactor<-c(rep(1,length(annot.$Condition)))
		cds.<-estimateDispersions(cds.,fitType="local")
		pvals <- nbinomTest(cds.,"ref","gpsamp")
		colnames(pvals) <- c("id","meanCount","meanCount.ref","meanCount.gpsamp","FC.gpsamp","log2FC.gpsamp","pval.gpsamp","qval.gpsamp")		
		res <- data.frame(res,pvals[,c("meanCount","meanCount.ref","meanCount.gpsamp","FC.gpsamp","log2FC.gpsamp","pval.gpsamp","qval.gpsamp")])
		colnames(res) <- sub("ref",names(ref)[min(c(k,length(ref)))],sub("gpsamp",names(groups)[k],colnames(res)))		

	}
	
	res
}				           


# Rd
# description >> Creates a summaryTable table with the number of genes under- or overexpressed in each group and outputs several graphical representations
# argument
# item >> restab >> Results table from geco.ChIPseqCompare
# item >> ref >> List containing one or more vectors of reference samples. Name of the vectors will be used in the results table. The length of this list should be 1 or the same length as the groups list
# item >> groups >> List containing the IDs of groups to be compared with the reference samples. Names of the vectors will be used in the results table
# item >> qval.th >> Q-value threshold to consider a gene as differentially expressed
# item >> plotdir >> Directory to which graphical representations should be plotted
# value >> Summary table
# author >> Eric Letouze & Celine Vallot
# keyword >> methods
# details >> ...
# seealso >> ...
# references >> ...
# examples >> ...
# end
geco.summaryChIPseqCompare <- function(restab=NULL,
									  ref=NULL,
							 		  groups=NULL,
  							 		  qval.th=0.1,
							 		  plotdir=NULL
							          )
{
	summaryTable <- matrix(nrow=3,ncol=length(groups),dimnames=list(c("diff","over","under"),names(groups)))
	
	for(k in 1:length(groups))
	{
		gpsamp <- names(groups)[k]
		if(length(ref)==1){refsamp <- names(ref)}else{refsamp <- names(ref)[k]}

		# Fill summaryTable table
		summaryTable["diff",gpsamp] <- sum(restab[,paste("qval",gpsamp,sep=".")] <= qval.th,na.rm=T)
		summaryTable["over",gpsamp] <- sum(restab[,paste("qval",gpsamp,sep=".")] <= qval.th & restab[,paste("log2FC",gpsamp,sep=".")] > 0,na.rm=T)
		summaryTable["under",gpsamp] <- sum(restab[,paste("qval",gpsamp,sep=".")] <= qval.th & restab[,paste("log2FC",gpsamp,sep=".")] < 0,na.rm=T)
		
		pdf(file.path(plotdir,paste("Supervised_analysis_",gpsamp,".pdf",sep="")), height=5, width=5)
		# Histogram H1 proportion
		tmp <- geco.H1proportion(restab[,paste("pval",gpsamp,sep=".")])
		hist(restab[,paste("pval",gpsamp,sep=".")],breaks=seq(0,1,by=0.05),xlab="P-value",ylab="Frequency",main=paste(gpsamp," vs ",refsamp,"\n","H1 proportion: ",round(tmp,3),sep=""))
		# Volcano plot
		mycol <- rep("black",nrow(restab))
		mycol[which(restab[,paste("qval",gpsamp,sep=".")] <= qval.th & restab[,paste("log2FC",gpsamp,sep=".")] > 0)] <- "red"
		mycol[which(restab[,paste("qval",gpsamp,sep=".")] <= qval.th & restab[,paste("log2FC",gpsamp,sep=".")] < 0)] <- "forestgreen"
		plot(restab[,paste("log2FC",gpsamp,sep=".")],-log10(restab[,paste("qval",gpsamp,sep=".")]),col=mycol,pch=19,cex=0.2,xlab="log2(fold-change)",ylab="-log10(q-value)",las=1,main=paste(gpsamp,"vs",refsamp,"\n",summaryTable["over",gpsamp],"enriched,",summaryTable["under",gpsamp],"depleted"))
		abline(v=0,lty=2);abline(h=-log10(qval.th),lty=2)
		# MA plot
		mypch <- rep(19,nrow(restab))
		x <- log10(restab[,paste("meanCount",gpsamp,sep=".")])
		y <- restab[,paste("log2FC",gpsamp,sep=".")]
		mypch[which(y > 2)] <- 2;y[which(y > 2)] <- 2;mypch[which(y < -2)] <- 6;y[which(y < -2)] <- -2
		plot(x,y,col=mycol,cex=0.2,xlab="mean of normalized counts",ylab="log2(fold-change)",las=1,main=paste(gpsamp,"vs",refsamp,"\n",summaryTable["over",gpsamp],"enriched,",summaryTable["under",gpsamp],"depleted"),xlim=c(1,max(x)),pch=mypch,xaxt="n")
		axis(1,at=seq(1,round(ceiling(max(x))),by=2),labels=10^seq(1,round(ceiling(max(x))),by=2))
		dev.off()
	}
	
	pdf(file.path(plotdir,"Number_differentially_bound_peaks_per_group.pdf"))
	myylim <- range(c(summaryTable["over",],-summaryTable["under",]))
	barplot(summaryTable["over",],col="red",las=1,ylim=myylim,main="Differentially bound peaks",ylab="Number of peaks",axes=F)
	barplot(-summaryTable["under",],col="forestgreen",ylim=myylim,add=T,axes=F,names.arg="")
	z <- axis(2,pos=-10)
	axis(2,at=z,labels=abs(z),las=1)
	dev.off()			
	
	summaryTable
}


# Rd
# description >> Function to compare ChIP-seq expression levels between one or more test groups and one or more reference groups using Limma package
# argument
# item >> mat >> Pseudo-count matrix pour ChIPseq experiments
# item >> metadata >> Metadata file used for creating cds objects with DESeq.
# item >> ref >> List containing one or more vectors of reference samples. Name of the vectors will be used in the results table. The length of this list should be 1 or the same length as the groups list
# item >> groups >> List containing the IDs of groups to be compared with the reference samples. Names of the vectors will be used in the results table
# item >> featureTab >> Feature annotations to be added to the results table
# value >> Results table
# author >>  Celine Vallot 
# keyword >> methods
# details >> ...
# seealso >> ...
# references >> ...
# examples >> ...
# end

geco.ChIPseqCompareLimma <- function (mat = NULL, metadata = NULL, ref = NULL, groups = NULL, 
                                      featureTab = NULL) 
{
  res <- featureTab
  res$id <- rownames(res)
  for (k in 1:length(groups)) {
    print(paste("Comparing", names(ref)[min(c(k, length(ref)))], 
                "versus", names(groups)[k]))
    if (length(ref) == 1) {
      refsamp <- ref[[1]]
    }
    else {
      refsamp <- ref[[k]]
    }
    gpsamp <- groups[[k]]
    metadata. <- metadata[c(refsamp, gpsamp), 1:2]
    metadata.$condition <- c(rep("ref", length(refsamp)), 
                             rep("x_gpsamp", length(gpsamp)))
    mat. <- mat[, c(refsamp, gpsamp)]
    y <- DGEList(counts = mat., genes = as.vector(featureTab$Gene))
    y <- calcNormFactors(y)
    design <- model.matrix(~condition, data = metadata.)
    v <- voom(y, design, plot = TRUE)
    fit <- lmFit(v, design)
    fit <- eBayes(fit)
    res. <- topTable(fit, n = Inf, sort = "p")
    colnames(res.) <- c("log2FC.gp", "AveExp", "t", 
                        "pval.gp", "qval.gp", "B")
    res.$id <- rownames(res.)
    res. <- res.[order(res.$id), ]
    
    res <- left_join(res,res.[, c("id","log2FC.gp", "pval.gp", "qval.gp")], check.names = FALSE)
    colnames(res) <- sub("ref", names(ref)[min(c(k, length(ref)))], 
                         sub("gp", names(groups)[k], colnames(res)))
  }
  res
}


# Rd
# description >> Creates a summaryTable table with the number of genes under- or overexpressed in each group and outputs several graphical representations
# argument
# item >> restab >> Results table from geco.ChIPseqCompare
# item >> ref >> List containing one or more vectors of reference samples. Name of the vectors will be used in the results table. The length of this list should be 1 or the same length as the groups list
# item >> groups >> List containing the IDs of groups to be compared with the reference samples. Names of the vectors will be used in the results table
# item >> col.sign >> Column where to extract significance from
# item >> sign.th >> Significance threshold to consider a gene as differentially expressed
# item >> plotdir >> Directory to which graphical representations should be plotted
# value >> summaryTable table
# author >> Celine Vallot
# keyword >> methods
# details >> ...
# seealso >> ...
# references >> ...
# examples >> ...
# end
geco.summaryChIPseqCompareLimma <- function(restab=NULL,
                                            ref=NULL,
                                            groups=NULL,
                                            col.sign="qval",
                                            sign.th=0.05,
                                            fc.th=1,
                                            plotdir=NULL,
                                            barplot_las=1,
                                            barplot_width=7,
                                            barplot_height=7,
                                            barplot_cex_names=0.8,
                                            barplot_mai=c(2,1,1,1),
                                            volcano_dotcex= 0.2,
                                            volcano_dot_alpha= 1,
                                            volcano_add_xlim = 0.2,
                                            scatter_dot_alpha=0.2,
                                            display_top_names=0,
                                            feature_name="Gene",
                                            MA_dotcex=0.2,
                                            barplot_space=1,
                                            barplot_print_numbers=TRUE,
                                            barplot_number_cex=1,
                                            barplot_ylimFactorOver=1.5,
                                            barplot_ylimFactorUnder=1.5)
{
    if(!file.exists(plotdir))	dir.create(plotdir)
    
    summaryTable <- matrix(nrow=3,ncol=length(groups),dimnames=list(c("diff","over","under"),names(groups)))
    
    for(k in 1:length(groups))
    {
        gpsamp <- names(groups)[k]
        if(length(ref)==1){refsamp <- names(ref)}else{refsamp <- names(ref)[k]}
        
        # Fill summaryTable table
        summaryTable["diff",gpsamp] <- sum(restab[,paste(col.sign,gpsamp,sep=".")] <= sign.th & abs(restab[,paste("log2FC",gpsamp,sep=".")]) > fc.th ,na.rm=T)
        summaryTable["over",gpsamp] <- sum(restab[,paste(col.sign,gpsamp,sep=".")] <= sign.th & restab[,paste("log2FC",gpsamp,sep=".")] > fc.th,na.rm=T)
        summaryTable["under",gpsamp] <- sum(restab[,paste(col.sign,gpsamp,sep=".")] <= sign.th & restab[,paste("log2FC",gpsamp,sep=".")] < -fc.th,na.rm=T)
        
        #png(file.path(plotdir,paste0("Supervised_analysis_ScatterPlot_",gpsamp,"_vs_",refsamp,".png")),width=1200,height=1200,res=200)
        # Scatter plot
        #plot(log2(restab[,paste("fpkm",refsamp,sep=".")]),log2(restab[,paste("fpkm",gpsamp,sep=".")]),col=mycol,pch=19,cex=scatter_dotcex,xlab=paste("log2(FPKM) in",refsamp),ylab=paste("log2(FPKM) in",gpsamp),main=paste(gpsamp,"vs",refsamp,"\n",summaryTable["over",gpsamp],"overexpressed,",summaryTable["under",gpsamp],"underexpressed"))
        #abline(0,1,lty=2)
        #dev.off()
        mycol <- rep("black",nrow(restab))
        mycol[which(restab[,paste(col.sign,gpsamp,sep=".")] <= sign.th & restab[,paste("log2FC",gpsamp,sep=".")] > fc.th)] <- "red"
        mycol[which(restab[,paste(col.sign,gpsamp,sep=".")] <= sign.th & restab[,paste("log2FC",gpsamp,sep=".")] < -fc.th)] <- "forestgreen"
        
        name = ifelse(display_top_names>0,paste0("Supervised_analysis_VolcanoPlot_",gpsamp,"_vs_",refsamp,"_topGenes_",display_top_names,".png"),
                      paste0("Supervised_analysis_VolcanoPlot_",gpsamp,"_vs_",refsamp,".png"))
        png(file.path(plotdir,name),width=1200,height=1200,res=200)
        # Volcano plot
        plot(restab[,paste("log2FC",gpsamp,sep=".")],-log10(restab[,paste(col.sign,gpsamp,sep=".")]),
             col=alpha(mycol,volcano_dot_alpha),pch=19, cex=volcano_dotcex,
             xlab="log2(fold-change)",
             ylab=paste("-log10(",col.sign,")",sep=""),
             xlim = c(min(restab[,paste("log2FC",gpsamp,sep=".")])-volcano_add_xlim,
                      max(restab[,paste("log2FC",gpsamp,sep=".")])+volcano_add_xlim),
             las=1,main=paste(gpsamp,"vs",refsamp,"\n",
                              summaryTable["over",gpsamp],"overexpressed,",
                              summaryTable["under",gpsamp],"underexpressed"))
        
        abline(v=-fc.th,lty=2)
        abline(v=fc.th,lty=2)
        abline(h=-log10(sign.th),lty=2)
        
        if(display_top_names > 0){
            top_res = restab[which(restab[,paste(col.sign,gpsamp,sep=".")] < sign.th & 
                                       abs(restab[,paste("log2FC",gpsamp,sep=".")]) > fc.th),]
            if(nrow(top_res) < display_top_names) display_top_names = nrow(top_res)
            if(display_top_names > 0){
                top_res = top_res[order(top_res[,paste(col.sign,gpsamp,sep=".")]),]
                top_res = top_res[order(abs(top_res[,paste("log2FC",gpsamp,sep=".")]),decreasing = T),]
                top_res = top_res[1:display_top_names,]
                top_features_IDs = as.character(top_res$ID)
                top_features_df = as.data.frame(top_res[top_features_IDs,])
                top_features = top_x = top_y = pos = col = offset = c()
                for(i in 1:display_top_names){
                    top_features = c(top_features,top_features_df[i,feature_name])
                    top_x[i] = top_res[i, paste("log2FC",gpsamp,sep=".")]
                    top_y[i] = -log10(top_res[i, paste(col.sign,gpsamp,sep=".")]) 
                    col[i] = ifelse(top_x[i]>0,"red","forestgreen")
                    pos[i] = ifelse(top_x[i]>0,4,2) 
                    offset[i] = 0.7
                }
                print(top_features)
                text(top_x,top_y,pos = pos, offset = offset, labels = top_features,col=col)
            }
        }
        
        dev.off()
        
        colnames(summaryTable)[k] <- paste0(gpsamp,"_vs_",refsamp) # SG 6/6/16  change names in table to include controls
    }
    
    png(file.path(plotdir,"Number_differentially_expressed_genes_per_group.png"),width=1200,height=1200,res=200)
    myylimOver <- range(c(summaryTable["over",]))*barplot_ylimFactorOver
    myylimUnder <- range(-summaryTable["under",])*barplot_ylimFactorUnder
    myylim  <- range(c(myylimOver, myylimUnder))
    if (max(nchar(colnames(summaryTable))) >=15 | ncol(summaryTable)>2) {barplot_mai <- c(3,1,1,1)}
    if (max(nchar(colnames(summaryTable))) >=25 ) {barplot_mai <- c(5,1,1,1)}
    if (ncol(summaryTable)>2) {barplot_las <- 2}
    par(mai=barplot_mai)
    xx <- barplot(summaryTable["over",],col="red",ylim=myylim,main="Differentially expressed genes",ylab="Nb of genes",axes=F,names.arg="", space=barplot_space) # added cex.names to fit long names
    yy <- barplot(-summaryTable["under",],col="forestgreen",ylim=myylim,add=T,axes=F,names.arg=colnames(summaryTable),las=barplot_las,cex.names=barplot_cex_names, space=barplot_space)
    if (barplot_print_numbers){
        text(x = xx, y = summaryTable["over",], label = summaryTable["over",], pos = 3, cex = barplot_number_cex, col = "red")
        text(x = yy, y = -summaryTable["under",], label = summaryTable["under",], pos = 1, cex = barplot_number_cex, col = "forestgreen") }
    z <- axis(2,pos=-10)
    axis(2,at=z,labels=abs(z),las=1)
    dev.off()
    
    summaryTable
}