# Rd
# description >> Function to compare RNA-seq expression levels between one or more test groups and one or more reference groups
# argument
# item >> htseqdir >> Directory containing the outputs from htseqCount
# item >> fpkm >> Normalized FPKM expression matrix
# item >> metadata >> Metadata file used for creating cds objects with DESeq.
# item >> ref >> List containing one or more vectors of reference samples. Name of the vectors will be used in the results table. The length of this list should be 1 or the same length as the groups list
# item >> groups >> List containing the IDs of groups to be compared with the reference samples. Names of the vectors will be used in the results table
# item >> featureTab >> Feature annotations to be added to the results table
# value >> Results table
# author >> Eric Letouze
# keyword >> methods
# details >> ...
# seealso >> ...
# references >> ...
# examples >> ...
# end
geco.RNAseqCompare <- function(htseqdir=NULL,
								fpkm=NULL,
								metadata=NULL,
								sample.col="sample",
								ref=NULL,
								groups=NULL,
								featureTab=NULL
								)
{
	res <- featureTab
	
	for(k in 1:length(groups))
	{
		print(paste("Comparing",names(ref)[min(c(k,length(ref)))],"versus",names(groups)[k]))
		if(length(ref)==1){refsamp <- ref[[1]]}else{refsamp <- ref[[k]]}
		gpsamp <- groups[[k]]
		fpkm.ref <- apply(matrix(fpkm[,refsamp],ncol=length(refsamp)),1,mean,na.rm=T)
		fpkm.gp <- apply(matrix(fpkm[,gpsamp],ncol=length(gpsamp)),1,mean,na.rm=T)
		
		metadata. <- metadata[match(c(refsamp,gpsamp),metadata[,sample.col]),1:2];metadata.$condition <- c(rep("ref",length(refsamp)),rep("gp",length(gpsamp)))
		cds. <- newCountDataSetFromHTSeqCount(metadata.,htseqdir)
		cds. <- cds.[rownames(fpkm),]
		cds. <- estimateSizeFactors(cds.)
		mode <- as.numeric(length(gpsamp) > 1 & length(refsamp) > 1)+1
		cds. <- estimateDispersions(cds.,method=c("blind","per-condition")[mode],sharingMode=c("fit-only","maximum")[mode])
		pvals <- nbinomTest(cds.,"ref","gp")
		colnames(pvals) <- c("id","meanCount","meanCount.ref","meanCount.gp","FC.gp","log2FC.gp","pval.gp","qval.gp")
		
		res <- data.frame(res,fpkm.ref=fpkm.ref,fpkm.gp=fpkm.gp,pvals[,c("meanCount.ref","meanCount.gp","FC.gp","log2FC.gp","pval.gp","qval.gp")])
		colnames(res) <- sub("ref",names(ref)[min(c(k,length(ref)))],sub("gp",names(groups)[k],colnames(res)))		
	}
	
	res
}				           


# Rd
# description >> Creates a summaryTable table with the number of genes under- or overexpressed in each group and outputs several graphical representations
# argument
# item >> restab >> Results table from geco.RNAseqCompare
# item >> ref >> List containing one or more vectors of reference samples. Name of the vectors will be used in the results table. The length of this list should be 1 or the same length as the groups list
# item >> groups >> List containing the IDs of groups to be compared with the reference samples. Names of the vectors will be used in the results table
# item >> col.sign >> Column where to extract significance from
# item >> sign.th >> Significance threshold to consider a gene as differentially expressed
# item >> plotdir >> Directory to which graphical representations should be plotted
# value >> summaryTable table
# author >> Eric Letouze
# keyword >> methods
# details >> ...
# seealso >> ...
# references >> ...
# examples >> ...
# end
geco.summaryRNAseqCompare <- function(restab=NULL,
									  ref=NULL,
									  groups=NULL,
									  col.sign="qval",
									  sign.th=0.05,
									  plotdir=NULL,
									  barplot_las=1,
									  barplot_width=7,
									  barplot_height=7,
									  barplot_cex_names=0.8,
									  barplot_mai=c(2,1,1,1),
									  volcano_dotcex= 0.2,
									  scatter_dotcex=0.2,
									  MA_dotcex=0.2,
									  barplot_space=1,
									  barplot_print_numbers=TRUE,
									  barplot_number_cex=1,
									  barplot_ylimFactorOver=1.5,
									  barplot_ylimFactorUnder=1.5)
{
	if(!file.exists(plotdir))	dir.create(plotdir)

	summaryTable <- matrix(nrow=3,ncol=length(groups),dimnames=list(c("diff","over","under"),names(groups)))
	
	for(k in 1:length(groups))
	{
		gpsamp <- names(groups)[k]
		if(length(ref)==1){refsamp <- names(ref)}else{refsamp <- names(ref)[k]}

		# Fill summaryTable table
		summaryTable["diff",gpsamp] <- sum(restab[,paste(col.sign,gpsamp,sep=".")] <= sign.th,na.rm=T)
		summaryTable["over",gpsamp] <- sum(restab[,paste(col.sign,gpsamp,sep=".")] <= sign.th & restab[,paste("log2FC",gpsamp,sep=".")] > 0,na.rm=T)
		summaryTable["under",gpsamp] <- sum(restab[,paste(col.sign,gpsamp,sep=".")] <= sign.th & restab[,paste("log2FC",gpsamp,sep=".")] < 0,na.rm=T)
		
	pdf(file.path(plotdir,paste0("Supervised_analysis__",gpsamp,"_vs_",refsamp,".pdf"))) # SG 6/6/16 Added the refsamp
		# Histogram H1 proportion
		tmp <- geco.H1proportion(restab[,paste("pval",gpsamp,sep=".")])
		hist(restab[,paste("pval",gpsamp,sep=".")],breaks=seq(0,1,by=0.05),xlab="P-value",ylab="Frequency",main=paste(gpsamp," vs ",refsamp,"\n","H1 proportion: ",round(tmp,3),sep=""))
		# Define colors
		mycol <- rep("black",nrow(restab))
		mycol[which(restab[,paste(col.sign,gpsamp,sep=".")] <= sign.th & restab[,paste("log2FC",gpsamp,sep=".")] > 0)] <- "red"
		mycol[which(restab[,paste(col.sign,gpsamp,sep=".")] <= sign.th & restab[,paste("log2FC",gpsamp,sep=".")] < 0)] <- "forestgreen"
		# Scatter plot
		plot(log2(restab[,paste("fpkm",refsamp,sep=".")]),log2(restab[,paste("fpkm",gpsamp,sep=".")]),col=mycol,pch=19,cex=scatter_dotcex,xlab=paste("log2(FPKM) in",refsamp),ylab=paste("log2(FPKM) in",gpsamp),main=paste(gpsamp,"vs",refsamp,"\n",summaryTable["over",gpsamp],"overexpressed,",summaryTable["under",gpsamp],"underexpressed"))
		abline(0,1,lty=2)
		# Volcano plot
		plot(restab[,paste("log2FC",gpsamp,sep=".")],-log10(restab[,paste(col.sign,gpsamp,sep=".")]),col=mycol,pch=19,cex=volcano_dotcex,xlab="log2(fold-change)",ylab=paste("-log10(",col.sign,")",sep=""),las=1,main=paste(gpsamp,"vs",refsamp,"\n",summaryTable["over",gpsamp],"overexpressed,",summaryTable["under",gpsamp],"underexpressed"))
		abline(v=0,lty=2);abline(h=-log10(sign.th),lty=2)
		# MA plot
		mypch <- rep(19,nrow(restab))
		x <- log10(restab[,paste("meanCount",gpsamp,sep=".")])
		y <- restab[,paste("log2FC",gpsamp,sep=".")]
		mypch[which(y > 2)] <- 2;y[which(y > 2)] <- 2;mypch[which(y < -2)] <- 6;y[which(y < -2)] <- -2
		plot(x,y,col=mycol,cex=MA_dotcex,xlab="mean of normalized counts",ylab="log2(fold-change)",las=1,main=paste(gpsamp,"vs",refsamp,"\n",summaryTable["over",gpsamp],"overexpressed,",summaryTable["under",gpsamp],"underexpressed"),xlim=c(1,max(x)),pch=mypch,xaxt="n")
		axis(1,at=seq(1,round(ceiling(max(x))),by=2),labels=10^seq(1,round(ceiling(max(x))),by=2))
	dev.off()
		
	png(file.path(plotdir,paste0("Supervised_analysis_ScatterPlot",gpsamp,"_vs_",refsamp,".png")),width=1200,height=1200,res=200)
		# Scatter plot
		plot(log2(restab[,paste("fpkm",refsamp,sep=".")]),log2(restab[,paste("fpkm",gpsamp,sep=".")]),col=mycol,pch=19,cex=scatter_dotcex,xlab=paste("log2(FPKM) in",refsamp),ylab=paste("log2(FPKM) in",gpsamp),main=paste(gpsamp,"vs",refsamp,"\n",summaryTable["over",gpsamp],"overexpressed,",summaryTable["under",gpsamp],"underexpressed"))
		abline(0,1,lty=2)
	dev.off()

	png(file.path(plotdir,paste0("Supervised_analysis_VolcanoPlot_",gpsamp,"_vs_",refsamp,".png")),width=1200,height=1200,res=200)
		# Volcano plot
		plot(restab[,paste("log2FC",gpsamp,sep=".")],-log10(restab[,paste(col.sign,gpsamp,sep=".")]),col=mycol,pch=19,cex=volcano_dotcex,xlab="log2(fold-change)",ylab=paste("-log10(",col.sign,")",sep=""),las=1,main=paste(gpsamp,"vs",refsamp,"\n",summaryTable["over",gpsamp],"overexpressed,",summaryTable["under",gpsamp],"underexpressed"))
		abline(v=0,lty=2);abline(h=-log10(sign.th),lty=2)
	dev.off()

	png(file.path(plotdir,paste0("Supervised_analysis_MAPlot_",gpsamp,"_vs_",refsamp,".png")),width=1200,height=1200,res=200)
		# MA plot
		mypch <- rep(19,nrow(restab))
		x <- log10(restab[,paste("meanCount",gpsamp,sep=".")])
		y <- restab[,paste("log2FC",gpsamp,sep=".")]
		mypch[which(y > 2)] <- 2;y[which(y > 2)] <- 2;mypch[which(y < -2)] <- 6;y[which(y < -2)] <- -2
		plot(x,y,col=mycol,cex=MA_dotcex,xlab="mean of normalized counts",ylab="log2(fold-change)",las=1,main=paste(gpsamp,"vs",refsamp,"\n",summaryTable["over",gpsamp],"overexpressed,",summaryTable["under",gpsamp],"underexpressed"),xlim=c(1,max(x)),pch=mypch,xaxt="n")
		axis(1,at=seq(1,round(ceiling(max(x))),by=2),labels=10^seq(1,round(ceiling(max(x))),by=2))
	dev.off()
		
		
		
		colnames(summaryTable)[k] <- paste0(gpsamp,"_vs_",refsamp) # SG 6/6/16  change names in table to include controls
	}
	
	pdf(file.path(plotdir,"Number_differentially_expressed_genes_per_group.pdf"), width=barplot_width, height=barplot_height)
	myylimOver <- range(c(summaryTable["over",]))*barplot_ylimFactorOver
	myylimUnder <- range(-summaryTable["under",])*barplot_ylimFactorUnder
	myylim  <- range(c(myylimOver, myylimUnder))
	if (max(nchar(colnames(summaryTable))) >=15 | ncol(summaryTable)>2) {barplot_mai <- c(3,1,1,1)}
	if (ncol(summaryTable)>2) {barplot_las <- 2}
	par(mai=barplot_mai)
	xx <- barplot(summaryTable["over",],col="red",ylim=myylim,main="Differentially expressed genes",ylab="Nb of genes",axes=F,names.arg="", space=barplot_space) # added cex.names to fit long names
	yy <- barplot(-summaryTable["under",],col="forestgreen",ylim=myylim,add=T,axes=F,names.arg=colnames(summaryTable),las=barplot_las,cex.names=barplot_cex_names, space=barplot_space)
if (barplot_print_numbers){
	text(x = xx, y = summaryTable["over",], label = summaryTable["over",], pos = 3, cex = barplot_number_cex, col = "red")
	text(x = yy, y = -summaryTable["under",], label = summaryTable["under",], pos = 1, cex = barplot_number_cex, col = "forestgreen") }
z <- axis(2,pos=-10)
	axis(2,at=z,labels=abs(z),las=1)
	dev.off()			
	
	summaryTable
}






